'use strict';
/**
 * SPGlobal AEM Forms — Global Custom Functions
 *
 * Single shared clientlib for all adaptive forms.
 * Authors configure behaviour via Rule Editor → Invoke Function — no per-form JS needed.
 *
 * AEM clientlib category : sp-aem-platform.clientlibs.global.forms.common
 *
 * HOW TO ADD TO A FORM
 *   In AEM Author → Form Properties → Custom Functions → add the category above.
 *   The clientlib self-initialises via an IIFE at the bottom — no Rule Editor rules needed
 *   for standard setup. Rule Editor is only needed for custom per-form logic.
 *
 * FUNCTION INDEX
 * ──────────────────────────────────────────────────────────────────────────────
 *  ★ 17. initFormDropdowns          ONE call — loads ALL dropdowns on any form (use this first)
 *  ──────────────────────────────────────────────────────────────────────────────
 *  01. hideEmptyOption              Hide the empty placeholder row in a dropdown
 *  02. loadDropdown                 Populate any dropdown from a JSON API
 *  03. loadCountryState             Load country list + auto-wire state cascade
 *  04. loadStateOnCountryChange     Populate state dropdown when country changes
 *  05. loadDropdownFromServlet      Load dropdown using a DOM data-attribute URL
 *  06. loadJobFunctionOnCompanyChange  Cascade job-function from company-type
 *  07. loadProductCategoryItems     Cascade product items from a selected category
 *  08. initPrepopulation            Prepopulate form fields from data-user-profile-servlet
 *  09. isBusinessEmail              Returns true if email is NOT a personal domain
 *  10. validateCheckboxGroup        Returns true if at least one checkbox is checked
 *  11. wireEmailCompanySync         Re-sync company name when email field changes
 *  12. applyRatingsFormStyling      Fix HR / toggle-button styling on ratings forms
 *  13. applyPreferenceCenterSpacing Add spacing class on preference-center forms
 *  14. wireMarketingEmailOptIn      Show/hide marketing consent panel on email entry
 *  15. checkEmailExists             Async check if email is already registered
 *  16. validatePasswordMatch        Returns true if password and confirm-password match
 * ──────────────────────────────────────────────────────────────────────────────
 */

// ─── Private helpers ─────────────────────────────────────────────────────────
// (no @name → invisible in Rule Editor, but callable by the public functions)

/**
 * Resolves a dot-notation path inside an object.
 * Auto-parses intermediate JSON strings — handles the AEM Content Fragment Assets API
 * where properties.elements.X.value is a stringified JSON object/array.
 * Example: _getIn(data, 'properties.elements.dropdownListJson.value.sectorExpertise') → [...]
 */
function _getIn(obj, path) {
  if (!path) return obj;
  return path.split('.').reduce(function (o, k) {
    if (o == null) return undefined;
    var val = o[k];
    if (typeof val === 'string') {
      var t = val.trim();
      if (t[0] === '{' || t[0] === '[') {
        try { val = JSON.parse(val); } catch (e) {}
      }
    }
    return val;
  }, obj);
}

/**
 * Populates a <select> element from an items array.
 * Each item may be: { key, value } | { value, label } | plain string.
 * keepPlaceholder=true preserves the first option when its value is '' (the empty option).
 */
function _populateSelect(selectEl, items, keepPlaceholder) {
  if (!selectEl || !Array.isArray(items)) return;
  var placeholder = null;
  if (keepPlaceholder && selectEl.options.length > 0 && selectEl.options[0].value === '') {
    placeholder = selectEl.options[0].cloneNode(true);
  }
  selectEl.innerHTML = '';
  if (placeholder) selectEl.appendChild(placeholder);
  items.forEach(function (item) {
    var opt = document.createElement('option');
    if (typeof item === 'object' && item !== null) {
      opt.value       = item.key   != null ? item.key
                      : item.value != null ? item.value
                      : item.code  != null ? item.code  : '';
      opt.textContent = item.text  != null ? item.text  :
                        item.value != null ? item.value :
                        item.label != null ? item.label : opt.value;
    } else {
      opt.value = opt.textContent = String(item);
    }
    selectEl.appendChild(opt);
  });
}

/**
 * Updates a dropdown field's options via the guideBridge model so AEM's overlay widget
 * re-renders. Falls back to native <select> DOM manipulation for non-AEM contexts.
 * fieldName is the bare field name (no leading dot), e.g. 'ratings_country'.
 */
function _setFieldOptions(fieldName, items) {
  var vals = items.map(function (i) {
    return i.key != null ? String(i.key)
         : i.value != null ? String(i.value)
         : i.code != null ? String(i.code)
         : String(i.text || '');
  });
  var labels = items.map(function (i) { return String(i.text || i.label || ''); });
  try {
    var node = guideBridge.resolveNode(fieldName);
    if (node && node.model) {
      node.model.enumNames = labels;
      node.model.enum = vals;
      // Give AEM time to re-render widget before hiding the empty placeholder
      setTimeout(function () { hideEmptyOption('.' + fieldName); }, 50);
      return;
    }
  } catch (e) {}
  // DOM fallback
  var sel = document.querySelector('.' + fieldName + ' select');
  if (sel) {
    _populateSelect(sel, items, true);
    hideEmptyOption('.' + fieldName);
  }
}

/**
 * Fetch JSON from url. Returns a Promise that resolves to the parsed object,
 * or null on HTTP/network error (so callers don't need individual .catch()).
 */
function _fetchJson(url) {
  return fetch(url, { credentials: 'include' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .catch(function () { return null; });
}

// ─── PUBLIC FUNCTIONS ────────────────────────────────────────────────────────


/**
 * @internal    hideEmptyOption — auto-called by _setFieldOptions after every API dropdown load; not needed in Rule Editor
 * @description Hides the empty placeholder row (data-empty-option) inside a dropdown wrapper.
 * @param       {string} wrapperClass  CSS class of the AEM field wrapper, e.g. '.energy_country'
 * @return      {void}
 */
function hideEmptyOption(wrapperClass) {
  var el = document.querySelector(wrapperClass + ' [data-empty-option]');
  if (el) el.classList.add('hidden');
}


/**
 * @internal    loadDropdown — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Fetches a JSON API and populates a dropdown with the result.
 *              Use for: country-of-residence lists, job-function lists, industry lists,
 *              company-type initial loads, MOC region lists, and any other single-level dropdown.
 *              Example: loadDropdown('/api/assets/.../job-function-cf.json', '.energy_Job_Function__c', 'JobFunction.option')
 * @param       {string} apiUrl       Full URL of the JSON endpoint (pass as hidden-field value or data-attribute)
 * @param       {string} wrapperClass CSS class of the AEM field wrapper, e.g. '.energy_country'
 * @param       {string} jsonPath     Dot-notation path to the items array inside the JSON response.
 *                                    Leave blank if the root is already an array.
 *                                    Examples: 'countryList', 'JobFunction.option', 'companyTypeList'
 * @return      {void}
 */
function loadDropdown(apiUrl, wrapperClass, jsonPath) {
  if (!apiUrl || !wrapperClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var items = _getIn(data, jsonPath);
    if (!Array.isArray(items)) return;
    _setFieldOptions(wrapperClass.replace(/^\./, ''), items);
  });
}


/**
 * @internal    loadCountryState — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Fetches a country-states JSON, populates the country dropdown, and
 *              automatically wires the state dropdown to cascade when the country changes.
 *              Call on guideRootPanel Initialize (runs once on form load).
 *              The JSON must have structure: { "countryList": [{ "key":"US", "value":"United States", "states":[{"key":"CA","value":"California"}] }] }
 *              Example: loadCountryState(countryStatesUrl.value, '.energy_country', '.energy_state', 'energy_state')
 * @param       {string} apiUrl          URL of the country-states JSON (read from hidden field via guideBridge)
 * @param       {string} countryClass    CSS class of the country dropdown wrapper, e.g. '.energy_country'
 * @param       {string} stateClass      CSS class of the state dropdown wrapper, e.g. '.energy_state'
 * @param       {string} stateFieldName  guideBridge field name for the state field (used to reset value on country change)
 * @return      {void}
 */
function loadCountryState(apiUrl, countryClass, stateClass, stateFieldName) {
  if (!apiUrl || !countryClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;

    var cSel = document.querySelector(countryClass + ' select');
    if (!cSel) return;
    _populateSelect(cSel, countryList, true);

    if (!stateClass) return;

    cSel.addEventListener('change', function () {
      var selected = countryList.find(function (c) {
        var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
        return k === cSel.value;
      });
      var states = selected && Array.isArray(selected.states) ? selected.states : [];
      var sSel = document.querySelector(stateClass + ' select');
      if (sSel) _populateSelect(sSel, states, true);
      if (stateFieldName) {
        try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
      }
    });
  });
}


/**
 * @internal    loadStateOnCountryChange — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Populates the state dropdown for a given country value.
 *              Call on the country field's Value Commit event.
 *              Arg 1 may be a direct API URL OR a data-attribute name (e.g. 'data-ratings-country-state-cf-servlet').
 *              For AEM Content Fragment CFs, pass the same jsonPath used in the Initialize rule as arg 5
 *              so the function can locate the countryList inside the nested CF response.
 *              Example (Value Commit on ratings_country — CF servlet):
 *                loadStateOnCountryChange('data-ratings-country-state-cf-servlet', ratings_country.value, '.ratings_state', 'ratings_state', 'properties.elements.dropdownListJson.value.countryList')
 *              Example (Value Commit — plain API URL):
 *                loadStateOnCountryChange(countryStatesUrl.value, ratings_country.value, '.ratings_state', 'ratings_state')
 * @param       {string} apiUrlOrAttr        Direct API URL, OR a data-attribute name starting with 'data-'
 * @param       {string} selectedCountryKey  The currently selected country value (pass as fieldName.value in Rule Editor)
 * @param       {string} stateClass          CSS class of the state dropdown wrapper, e.g. '.ratings_state'
 * @param       {string} stateFieldName      guideBridge field name for the state field (to reset on change)
 * @param       {string} countryListJsonPath Optional dot-notation path to the countryList array inside the response.
 *                                           Required when the JSON is a CF response, e.g. 'properties.elements.dropdownListJson.value.countryList'
 * @return      {void}
 */
function loadStateOnCountryChange(apiUrlOrAttr, selectedCountryKey, stateClass, stateFieldName, countryListJsonPath) {
  if (!selectedCountryKey || !stateClass) return;
  var url = apiUrlOrAttr;
  if (apiUrlOrAttr && apiUrlOrAttr.slice(0, 5) === 'data-') {
    var attrEl = document.querySelector('[' + apiUrlOrAttr + ']');
    if (!attrEl) return;
    url = attrEl.getAttribute(apiUrlOrAttr);
  }
  if (!url) return;
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var countryList = countryListJsonPath ? _getIn(data, countryListJsonPath) : null;
    if (!Array.isArray(countryList)) countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;
    var country = countryList.find(function (c) {
      var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
      return k === String(selectedCountryKey);
    });
    var states = country && Array.isArray(country.states) ? country.states : [];
    var sSel = document.querySelector(stateClass + ' select');
    if (sSel) _populateSelect(sSel, states, true);
    if (stateFieldName) {
      try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
    }
  });
}


/**
 * @name        loadDropdownFromServlet
 * @description Reads a servlet URL from a DOM data-attribute, fetches JSON, and populates a dropdown.
 *              Used for Ratings and CI/Energy servlet-driven dropdowns where the BE sets the URL
 *              on a container element (e.g. data-ratings-country-state-cf-servlet="...").
 *
 *              AUTO-DETECT: When jsonPath is blank, the function automatically locates the items
 *              array inside the AEM Content Fragment response
 *              (properties.elements.dropdownListJson.value → first array found).
 *              You only need to pass jsonPath if you want a specific key from that object.
 *
 *              STATE CASCADE: Pass stateClass and stateFieldName (args 4 & 5) to automatically
 *              wire the state dropdown — no separate Value Commit rule needed.
 *              The countryList items must have a 'states' array property per country.
 *
 *              Example — simple dropdown, no jsonPath needed:
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise')
 *              Example — country + state cascade in one rule (Initialize only):
 *                loadDropdownFromServlet('data-ratings-country-state-cf-servlet', '.ratings_country', '', '.ratings_state', 'ratings_state')
 *              Example — explicit jsonPath (when auto-detect would pick the wrong key):
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise', 'properties.elements.dropdownListJson.value.sectorExpertise')
 *
 * @param       {string} servletAttrName  The data-attribute name that holds the servlet URL
 * @param       {string} wrapperClass     CSS class of the dropdown wrapper to populate, e.g. '.ratings_country'
 * @param       {string} jsonPath         Optional. Dot-notation path to items. Leave blank for auto-detect.
 * @param       {string} stateClass       Optional. CSS class of the state dropdown to wire, e.g. '.ratings_state'
 * @param       {string} stateFieldName   Optional. guideBridge field name for the state field (to reset on country change)
 * @return      {void}
 */
function loadDropdownFromServlet(servletAttrName, wrapperClass, jsonPath, stateClass, stateFieldName) {
  if (!servletAttrName || !wrapperClass) return;
  var el = document.querySelector('[' + servletAttrName + ']');
  if (!el) return;
  var url = el.getAttribute(servletAttrName);
  if (!url) return;
  _loadDropdownFromUrl(url, wrapperClass, jsonPath, stateClass, stateFieldName);
}

/**
 * @internal  AEM puts data-dropdown-json on the inner .guideFieldWidget div, not the outer wrapper.
 *            Check the element itself first, then fall back to any child that has the attribute.
 */
function _getDropdownJsonUrl(el) {
  var url = el.getAttribute('data-dropdown-json');
  if (url) return url;
  var inner = el.querySelector('[data-dropdown-json]');
  return inner ? inner.getAttribute('data-dropdown-json') : null;
}

/**
 * @internal  Shared fetch+populate logic used by loadDropdownFromServlet and initFormDropdowns.
 *            Not intended for direct use in Rule Editor.
 */
function _loadDropdownFromUrl(url, wrapperClass, jsonPath, stateClass, stateFieldName) {
  if (!url || !wrapperClass) return;

  if (jsonPath) {
    loadDropdown(url, wrapperClass, jsonPath);
    return;
  }

  // Auto-detect: parse CF response and grab the first array inside dropdownListJson.value
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var inner = _getIn(data, 'properties.elements.dropdownListJson.value')
             || _getIn(data, 'elements.dropdownListJson.value');
    // CF stores the dropdown list as a JSON string inside the value field — parse it first
    if (typeof inner === 'string') {
      try { inner = JSON.parse(inner); } catch (e) { inner = null; }
    }
    var items = null;
    if (inner && typeof inner === 'object' && !Array.isArray(inner)) {
      var keys = Object.keys(inner);
      for (var i = 0; i < keys.length; i++) {
        if (Array.isArray(inner[keys[i]])) { items = inner[keys[i]]; break; }
      }
    }
    if (!items) items = Array.isArray(data) ? data : null;
    if (!Array.isArray(items)) return;

    var countryFieldName = wrapperClass.replace(/^\./, '');
    _setFieldOptions(countryFieldName, items);

    if (stateClass && items.some(function (c) { return Array.isArray(c.states); })) {
      var stFN = stateClass.replace(/^\./, '');

      var handleCountryChange = function (val) {
        if (!val) return;
        var selected = items.find(function (c) {
          var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
          return k === String(val);
        });
        var states = selected && Array.isArray(selected.states) ? selected.states : [];

        // Show/hide + mandatory mirrors what the old 6.5 code did via guideBridge
        try {
          var stateNode = guideBridge.resolveNode(stFN);
          if (stateNode) {
            stateNode.value     = '';
            stateNode.visible   = states.length > 0;
            stateNode.mandatory = states.length > 0;
          }
        } catch (e) {}

        // Populate options via native DOM — same approach as original 6.5 code
        var sSel = document.querySelector(stateClass + ' select');
        if (sSel) {
          sSel.innerHTML = '';
          states.forEach(function (s) {
            var opt = document.createElement('option');
            opt.value       = s.text || s.code || s.value || '';
            opt.textContent = s.text || '';
            sSel.appendChild(opt);
          });
        }
      };

      var _lastCV = '';
      // Primary: guideBridge elementValueChanged — old 6.5 code used data.target (not data.resolvedNode)
      try {
        guideBridge.on('elementValueChanged', function (event, data) {
          var node = data && data.target;
          if (!node || node.name !== countryFieldName) return;
          var v = node.value;
          if (v && v !== _lastCV) { _lastCV = v; handleCountryChange(v); }
        });
      } catch (e) {}

      // Fallback: poll guideBridge model — fires on prepopulation and any path guideBridge misses
      setInterval(function () {
        try {
          var v = guideBridge.resolveNode(countryFieldName).value;
          if (v && v !== _lastCV) { _lastCV = v; handleCountryChange(v); }
        } catch (e) {}
      }, 300);
    }
  });
}


/**
 * @internal    loadJobFunctionOnCompanyChange — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Cascades the job-function dropdown when the company-type selection changes.
 *              Fetches the company-type JSON, finds the selected company entry, and populates
 *              the job-function dropdown with that company's jobFunctions array.
 *              Call on the company-type field's Value Commit event.
 *              Example (Value Commit on market-intelligence_Company_Type1__c):
 *                loadJobFunctionOnCompanyChange(companyJobFunctionUrl.value, market-intelligence_Company_Type1__c.value, 'market-intelligence_Job_Function1__c')
 * @param       {string} apiUrl                URL of the company-type/job-function JSON
 * @param       {string} selectedCompanyType   Currently selected company-type value (pass fieldName.value)
 * @param       {string} jobFunctionFieldName  guideBridge field name for the job-function dropdown
 * @return      {void}
 */
function loadJobFunctionOnCompanyChange(apiUrl, selectedCompanyType, jobFunctionFieldName) {
  if (!apiUrl || !selectedCompanyType || !jobFunctionFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var companyList = data.companyTypeList || [];
    var match = companyList.find(function (c) {
      return (c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '') === String(selectedCompanyType);
    });
    var jobs = (match && Array.isArray(match.jobFunctions)) ? match.jobFunctions : [];
    try {
      var node = guideBridge.resolveNode(jobFunctionFieldName);
      if (node) {
        node.enum      = jobs.map(function (j) { return j.key   != null ? j.key   : j.value; });
        node.enumNames = jobs.map(function (j) { return j.value != null ? j.value : j.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @internal    loadProductCategoryItems — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Cascades product/service items when a product category is selected.
 *              Fetches the critical-business JSON, finds the matching category, and populates
 *              the product items dropdown.
 *              Call on the product-category field's Value Commit event.
 *              Example: loadProductCategoryItems(criticalBusinessUrl.value, productCategory.value, 'market-intelligence_S_P_Product_Service_Interests__c')
 * @param       {string} apiUrl             URL of the product/critical-business JSON
 * @param       {string} selectedCategory   Currently selected category value (pass fieldName.value)
 * @param       {string} itemsFieldName     guideBridge field name for the product items dropdown
 * @return      {void}
 */
function loadProductCategoryItems(apiUrl, selectedCategory, itemsFieldName) {
  if (!apiUrl || !selectedCategory || !itemsFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var categoryList = data.categoryList || data.productList || data.criticalBusinessList || [];
    var match = categoryList.find(function (c) {
      return (c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '') === String(selectedCategory);
    });
    var items = (match && Array.isArray(match.items)) ? match.items
      : (match && Array.isArray(match.products)) ? match.products : [];
    try {
      var node = guideBridge.resolveNode(itemsFieldName);
      if (node) {
        node.enum      = items.map(function (i) { return i.key   != null ? i.key   : i.value; });
        node.enumNames = items.map(function (i) { return i.value != null ? i.value : i.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @name        initPrepopulation
 * @description Prepopulates form fields from the user-profile API. Zero parameters.
 *              API URL read from data-user-profile-servlet set by BE on the form container.
 *              Field prefix auto-detected from the _prepopulate marker class on the form
 *              (e.g. .ratings_prepopulate → 'ratings_', .commodityinsights_prepopulate → 'commodityinsights_').
 *              Cookie check is derived automatically from the BU prefix:
 *                ratings / newsletter → SP_SSO_TOKEN
 *                commodityinsights / energy / sustainable1 → CI-AUTH-JWT (runs anyway if missing)
 *              Example: initPrepopulation()
 * @return      {void}
 */
function initPrepopulation() {
  var profileEl = document.querySelector('[data-user-profile-servlet]');
  var apiUrl    = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  if (!apiUrl) return;

  // Auto-detect field prefix from the _prepopulate marker class already on the form
  var fieldPrefix = '';
  var markerEl = document.querySelector('[class*="_prepopulate"]');
  if (markerEl) {
    var classes = markerEl.className.split(/\s+/);
    for (var ci = 0; ci < classes.length; ci++) {
      var m = classes[ci].match(/^([a-zA-Z][a-zA-Z0-9-]*)_prepopulate$/);
      if (m) { fieldPrefix = m[1] + '_'; break; }
    }
  }
  if (!fieldPrefix) return;

  // Cookie lookup by marker class prefix — ratings always uses SP_SSO_TOKEN,
  // commodityinsights/energy uses CI-AUTH-JWT (if missing, still run — covers all-users forms)
  var COOKIE_MAP = { ratings: 'SP_SSO_TOKEN', newsletter: 'SP_SSO_TOKEN', commodityinsights: 'CI-AUTH-JWT', energy: 'CI-AUTH-JWT', sustainable1: 'CI-AUTH-JWT' };
  var buPrefix = fieldPrefix.replace(/_$/, '');
  var cookieName = COOKIE_MAP[buPrefix] || '';
  if (cookieName) {
    var cookiePattern = new RegExp('(^|;)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
    if (!cookiePattern.test(document.cookie)) return;
  }

  _fetchJson(apiUrl).then(function (data) {
    if (!data || typeof data !== 'object') return;
    Object.keys(data).forEach(function (apiKey) {
      var val = data[apiKey];
      if (val == null || val === '') return;
      try {
        var node = guideBridge.resolveNode(fieldPrefix + apiKey);
        if (node) node.value = val;
      } catch (e) {}
    });
  });
}


/**
 * @name        checkEmailExists
 * @description Checks whether an email is already registered by calling the user-profile
 *              servlet. If the account exists, shows an error message element and hides
 *              the next/submit button. Used on the email field's Value Commit event in
 *              registration forms to prevent duplicate accounts.
 *              The check is async — the DOM updates after the API responds.
 *              Example: checkEmailExists(userProfileServletUrl.value, ratings_email.value, '[data-email-exist-message]', '[data-next-button]')
 * @param       {string} apiUrl             Profile servlet URL (from hidden field set by BE)
 * @param       {string} emailValue         Current email value (pass fieldName.value in Rule Editor)
 * @param       {string} errorSelector      CSS selector for the error message container to show/hide
 * @param       {string} nextButtonSelector CSS selector for the Next/Submit button to disable when email exists
 * @return      {void}
 */
function checkEmailExists(apiUrl, emailValue, errorSelector, nextButtonSelector) {
  if (!apiUrl) {
    var profileEl = document.querySelector('[data-user-profile-servlet]');
    apiUrl = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  }
  if (!apiUrl || !emailValue || emailValue.indexOf('@') === -1) return;
  var errorEl  = errorSelector      ? document.querySelector(errorSelector)      : null;
  var buttonEl = nextButtonSelector ? document.querySelector(nextButtonSelector) : null;

  fetch(apiUrl, {
    method     : 'POST',
    headers    : { 'Content-Type': 'application/json' },
    credentials: 'include',
    body       : JSON.stringify({ field: 'firstName,email', email: emailValue })
  })
  .then(function (r) { return r.ok ? r.json() : null; })
  .then(function (data) {
    if (!data) return;
    var exists = !!(data.userExists || data.exists || data.accountExists);
    if (errorEl)  errorEl.style.display  = exists ? 'block' : 'none';
    if (buttonEl) buttonEl.disabled      = exists;
  })
  .catch(function () {});
}


/**
 * @name        validatePasswordMatch
 * @description Returns true if the password and confirm-password fields contain the same value.
 *              Use in a Validate rule on both the password field and the confirm-password field.
 *              Example: validatePasswordMatch('.ratings_password', '.confirmPassword')
 * @param       {string} passwordSelector         CSS class of the password field wrapper
 * @param       {string} confirmPasswordSelector  CSS class of the confirm-password field wrapper
 * @return      {boolean}  true = passwords match (valid); false = mismatch (invalid)
 */
function validatePasswordMatch(passwordSelector, confirmPasswordSelector) {
  var pwdInput = document.querySelector(passwordSelector + ' input[type="password"]');
  var cfmInput = document.querySelector(confirmPasswordSelector + ' input[type="password"]');
  if (!pwdInput || !cfmInput) return true;
  return pwdInput.value === cfmInput.value;
}


/**
 * @name        isBusinessEmail
 * @description Returns true if the email address belongs to a business domain
 *              (i.e. is NOT a known personal/consumer email provider).
 *              Use in a field's Enabled or Validate rule on a submit button.
 *              Example (Enabled on Submit): isBusinessEmail(Corporate_email.value)
 * @param       {string} emailValue  The email address to check (pass fieldName.value)
 * @return      {boolean}            true = business email (allow submit); false = personal email (block submit)
 */
function isBusinessEmail(emailValue) {
  if (!emailValue || emailValue.indexOf('@') === -1) return true;
  var domain = emailValue.split('@').pop().toLowerCase();
  var personalDomains = [
    // Global
    'gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.uk', 'yahoo.co.in',
    'yahoo.com.au', 'yahoo.ca', 'yahoo.fr', 'yahoo.de', 'yahoo.es', 'yahoo.it',
    'hotmail.com', 'hotmail.co.uk', 'hotmail.fr', 'hotmail.de', 'hotmail.es', 'hotmail.it',
    'outlook.com', 'outlook.co.uk', 'outlook.fr', 'outlook.de', 'outlook.es',
    'live.com', 'live.co.uk', 'live.fr', 'live.de', 'live.es', 'live.it',
    'msn.com', 'aol.com', 'icloud.com', 'me.com', 'mac.com',
    'protonmail.com', 'protonmail.ch', 'proton.me',
    'zoho.com', 'zohomail.com',
    'inbox.com', 'mail.com', 'email.com', 'usa.com', 'hushmail.com',
    // Russia / Eastern Europe
    'yandex.ru', 'yandex.com', 'yandex.ua', 'yandex.kz', 'yandex.by',
    'mail.ru', 'list.ru', 'bk.ru', 'inbox.ru', 'rambler.ru',
    'ukr.net', 'mail.bg', 'abv.bg',
    // Germany
    'web.de', 'gmx.de', 'gmx.net', 'gmx.com', 'gmx.at', 'gmx.ch',
    'freenet.de', 't-online.de', 'arcor.de',
    // France
    'orange.fr', 'sfr.fr', 'laposte.net', 'free.fr', 'bbox.fr',
    'alice.fr', 'numericable.fr', 'wanadoo.fr', 'neuf.fr',
    // Spain / Italy
    'orange.es', 'terra.es', 'ya.com',
    'libero.it', 'virgilio.it', 'tin.it', 'alice.it', 'tiscali.it', 'fastwebnet.it',
    // Switzerland
    'bluewin.ch', 'sunrise.ch',
    // Brazil
    'bol.com.br', 'uol.com.br', 'globo.com', 'terra.com.br', 'r7.com',
    'ig.com.br', 'oi.com.br', 'pop.com.br', 'zipmail.com.br',
    // China / Asia
    'qq.com', '163.com', '126.com', 'sina.com', 'sina.cn', '139.com',
    'foxmail.com', 'sohu.com', 'aliyun.com', '21cn.com',
    // Korea
    'naver.com', 'daum.net', 'hanmail.net', 'nate.com', 'kakao.com',
    // Japan
    'docomo.ne.jp', 'softbank.ne.jp', 'au.com', 'ezweb.ne.jp',
    // Australia
    'bigpond.com', 'bigpond.net.au', 'optusnet.com.au',
    'internode.on.net', 'tpg.com.au', 'iinet.net.au', 'dodo.com.au',
    // India
    'rediffmail.com', 'sify.com',
    // Other common
    'tutanota.com', 'tutamail.com', 'dispostable.com', 'mailinator.com',
    'guerrillamail.com', 'trashmail.com', 'tempmail.com', 'throwam.com'
  ];
  return personalDomains.indexOf(domain) === -1;
}


/**
 * @name        validateCheckboxGroup
 * @description Returns true if at least one checkbox is checked inside the given container.
 *              Use in a Validate rule on a checkbox group panel.
 *              Example: validateCheckboxGroup('.acc-reg-alert-section')
 * @param       {string} containerSelector  CSS selector for the panel/div wrapping the checkboxes
 * @return      {boolean}                   true = valid (at least one checked); false = invalid
 */
function validateCheckboxGroup(containerSelector) {
  var container = document.querySelector(containerSelector);
  if (!container) return false;
  return container.querySelectorAll('input[type="checkbox"]:checked').length > 0;
}


/**
 * @name        wireEmailCompanySync
 * @description Attaches a focusout listener to the email input so that when the user changes
 *              their email address, the company-name field value is re-synced via guideBridge.
 *              The 2-second delay is required because AEM re-renders the field asynchronously.
 *              Auto-detects the company field across all BUs. No parameters needed.
 *              Call on guideRootPanel Initialize (or let the clientlib IIFE call it).
 * @return      {void}
 */
function wireEmailCompanySync() {
  var VARIANTS = [
    { wrapper: '.market-intelligence_sPGMICustomCompanyName', gbName: 'market-intelligence_sPGMICustomCompanyName' },
    { wrapper: '.ratings_Company_Name',                       gbName: 'ratings_Company_Name'                       },
    { wrapper: '.commodity-insights_company',                 gbName: 'commodity-insights_company'                 },
    { wrapper: '.energy_company',                             gbName: 'energy_company'                             },
    { wrapper: '.sustainable1_company',                       gbName: 'sustainable1_company'                       },
    { wrapper: '.Corporate_Company_Name',                     gbName: 'Corporate_Company_Name'                     },
  ];
  var emailInput = document.querySelector('.guideEmail input[type="email"]');
  if (!emailInput) return;
  var match = null;
  for (var i = 0; i < VARIANTS.length; i++) {
    if (document.querySelector(VARIANTS[i].wrapper)) { match = VARIANTS[i]; break; }
  }
  if (!match) return;
  emailInput.addEventListener('focusout', function () {
    setTimeout(function () {
      var inp = document.querySelector(match.wrapper + ' input');
      if (inp) {
        try { guideBridge.resolveNode(match.gbName).value = inp.value; } catch (e) {}
      }
    }, 2000);
  });
}


/**
 * @name        applyRatingsFormStyling
 * @description Removes unwanted min-height from HR elements in text draws, cleans up
 *              guideFieldError class on toggle buttons, and adds mb-8 spacing to the
 *              vertical-tab-dropdown. Identical fix required on all ratings forms.
 *              Call on guideRootPanel Initialize.
 * @return      {void}
 */
function applyRatingsFormStyling() {
  document.querySelectorAll('.guideTextDraw hr').forEach(function (hr) {
    hr.style.minHeight = '';
  });
  document.querySelectorAll('.toggleButton.guideFieldError').forEach(function (el) {
    el.classList.remove('guideFieldError');
  });
  var vtd = document.querySelector('.vertical-tab-dropdown');
  if (vtd) vtd.classList.add('mb-8');
}


/**
 * @name        applyPreferenceCenterSpacing
 * @description Walks up from .preference-center-parent to the nearest <form> element
 *              and adds the remove-x-padding class to remove horizontal padding.
 *              Call on guideRootPanel Initialize for preference-center and interest forms.
 * @return      {void}
 */
function applyPreferenceCenterSpacing() {
  var el = document.querySelector('.preference-center-parent');
  if (!el) return;
  var form = el.closest('form');
  if (form) form.classList.add('remove-x-padding');
}


/**
 * @name        wireMarketingEmailOptIn
 * @description Shows or hides the marketingEmailOptIn panel based on whether the email
 *              field has a value. Auto-detects the email field name across all BUs.
 *              Call on guideRootPanel Initialize (or let the clientlib IIFE call it).
 * @return      {void}
 */
function wireMarketingEmailOptIn() {
  var optInPanel = null;
  try { optInPanel = guideBridge.resolveNode('marketingEmailOptIn'); } catch (e) {}
  if (!optInPanel) return;

  // Try each known email field name — first one that resolves wins
  var EMAIL_VARIANTS = ['email', 'Corporate_Email', 'ratings_email',
                        'commodity-insights_email', 'energy_email'];
  var fieldName = null;
  for (var i = 0; i < EMAIL_VARIANTS.length; i++) {
    try { if (guideBridge.resolveNode(EMAIL_VARIANTS[i])) { fieldName = EMAIL_VARIANTS[i]; break; } } catch (e) {}
  }
  if (!fieldName) return;

  guideBridge.on('elementValueChanged', function () {
    try {
      var emailNode = guideBridge.resolveNode(fieldName);
      var panel     = guideBridge.resolveNode('marketingEmailOptIn');
      if (emailNode && panel) {
        panel.visible = (emailNode.value != null && emailNode.value !== '');
      }
    } catch (e) {}
  });
}


/**
 * @name        initFormDropdowns
 * @description Initialises ALL dropdowns on the current form in ONE call.
 *              Reads the JSON URL from a data-dropdown-json attribute on each field element
 *              (set by BE per field), fetches the JSON, and populates the dropdown.
 *              Country → State cascades are wired automatically (no separate Value Commit rule).
 *              Company Type → Job Function and Product Category → Product Items cascades
 *              are also wired automatically for MI forms.
 *              Fields that do not exist on the current form are silently skipped.
 *
 *              ── Required BE setup ───────────────────────────────────────────────────────
 *              BE must set data-dropdown-json="<servlet-url>" on each dropdown field element.
 *              The field wrapper class names are hardcoded below — each variant is tried and
 *              the first one found on the page is used.
 *
 *              ── NOT handled here (call separately) ──────────────────────────────────────
 *              initPrepopulation(cookieName, fieldPrefix) — cookie name and field prefix differ per form
 *              MOC forms — call loadDropdownFromServlet('data-countryregionmarket-servlet', '.yourClass') directly
 *
 *              Example (single rule on guideRootPanel Initialize):
 *                initFormDropdowns()
 *
 * @return      {void}
 */
function initFormDropdowns() {
  var LOAD_MAP = [
    // ── Ratings CF dropdowns ──────────────────────────────────────────────────
    { variants: [
        { field: '.ratings_country', stateField: '.ratings_state', stateGb: 'ratings_state' },
        { field: '.ratings_country', stateField: '.ratings_State', stateGb: 'ratings_State' }
    ]},
    { variants: [
        { field: '.ratings_Customer_Expertise__c' },
        { field: '.ratings_Customer_Expertise'    },
        { field: '.ratings_Sector_Expertise__c'   }
    ]},
    { variants: [
        { field: '.ratings_Customer_Segment__c' },
        { field: '.ratings_Customer_Segment'    }
    ]},
    { variants: [
        { field: '.ratings_Customer_Employer_Type__c' },
        { field: '.ratings_Customer_Employer_Type'    }
    ]},
    // ── CI / Energy / Sustainable (country + state cascade) ───────────────────
    { variants: [
        { field: '.ci_country',                 stateField: '.ci_state',                 stateGb: 'ci_state'                 },
        { field: '.commodity-insights_country', stateField: '.commodity-insights_state', stateGb: 'commodity-insights_state' },
        { field: '.energy_country',             stateField: '.energy_state',             stateGb: 'energy_state'             },
        { field: '.sustainable1_country',       stateField: '.sustainable1_state',       stateGb: 'sustainable1_state'       },
        { field: '.s1_country',                 stateField: '.s1_state',                 stateGb: 's1_state'                 }
    ]},
    // ── Country of residence (no state — single dropdown) ─────────────────────
    { variants: [
        { field: '.ci_country_Of_Residence'                     },
        { field: '.commodity-insights_Country_of_Residence__c'  },
        { field: '.energy_Country_of_Residence__c'              }
    ]},
    // ── Industry ──────────────────────────────────────────────────────────────
    { variants: [
        { field: '.ci_industry-dropdown'        },
        { field: '.commodity-insights_industry' },
        { field: '.energy_industry'             }
    ]},
    // ── Job function (initial load) ───────────────────────────────────────────
    { variants: [
        { field: '.ci_job-function-dropdown'           },
        { field: '.commodity-insights_Job_Function__c' },
        { field: '.energy_Job_Function__c'             }
    ]}
  ];

  LOAD_MAP.forEach(function (entry) {
    entry.variants.forEach(function (v) {
      var fieldEl = document.querySelector(v.field);
      if (!fieldEl) return;
      var url = _getDropdownJsonUrl(fieldEl);
      if (!url) return;
      _loadDropdownFromUrl(url, v.field, '', v.stateField || null, v.stateGb || null);
    });
  });

  // ── MI: company type + job function cascade ───────────────────────────────
  var companyEl = document.querySelector('.market-intelligence_Company_Type1__c');
  if (companyEl) {
    var companyUrl = _getDropdownJsonUrl(companyEl);
    if (companyUrl) {
      loadDropdown(companyUrl, '.market-intelligence_Company_Type1__c', 'companyTypeList');
      var compSel = companyEl.querySelector('select');
      if (compSel) {
        compSel.addEventListener('change', function () {
          loadJobFunctionOnCompanyChange(companyUrl, compSel.value, 'market-intelligence_Job_Function1__c');
        });
      }
    }
  }

  // ── MI: product category + product items cascade ──────────────────────────
  var productCatEl = document.querySelector('.market-intelligence_sPProductServiceInterestsCategory');
  if (productCatEl) {
    var productUrl = _getDropdownJsonUrl(productCatEl);
    if (productUrl) {
      loadDropdown(productUrl, '.market-intelligence_sPProductServiceInterestsCategory', 'categoryList');
      var catSel = productCatEl.querySelector('select');
      if (catSel) {
        catSel.addEventListener('change', function () {
          loadProductCategoryItems(productUrl, catSel.value, 'market-intelligence_S_P_Product_Service_Interests__c');
        });
      }
    }
  }

  // ── Generic fallback: load any [data-dropdown-json] not covered above ──────
  // Covers forms whose field class names don't match the LOAD_MAP entries.
  // Walks up to the .guideFieldNode ancestor to get the BU-specific CSS class,
  // then calls _loadDropdownFromUrl with no cascade (null stateClass).
  var _handled = {};
  LOAD_MAP.forEach(function (entry) {
    entry.variants.forEach(function (v) { _handled[v.field] = true; });
  });
  _handled['.market-intelligence_Company_Type1__c'] = true;
  _handled['.market-intelligence_sPProductServiceInterestsCategory'] = true;

  document.querySelectorAll('[data-dropdown-json]').forEach(function (el) {
    var url = el.getAttribute('data-dropdown-json');
    if (!url) return;
    var fieldNode = el.closest ? el.closest('.guideFieldNode') : null;
    if (!fieldNode) return;
    var buClass = null;
    var parts = (fieldNode.className || '').split(/\s+/);
    for (var j = 0; j < parts.length; j++) {
      var p = parts[j].trim();
      if (p && !/^(guide|aem-|coral|adaptive|af-|cmp-)/.test(p)) {
        buClass = p; break;
      }
    }
    if (!buClass) return;
    var sel = '.' + buClass;
    if (_handled[sel]) return;
    _handled[sel] = true;
    _loadDropdownFromUrl(url, sel, '', null, null);
  });
}


// ─── Self-initialising IIFE ───────────────────────────────────────────────────
// Fires once when guideBridge is ready. Calls every setup function — each one
// silently skips if its fields are not present on the current form.
// No Rule Editor rules needed for standard form setup.
(function () {

  // ── Private: wire isBusinessEmail to enable/disable submit button ───────────
  function _wireBusinessEmailValidation() {
    var EMAIL_FIELDS = [
      'email', 'Email', 'Corporate_email', 'Corporate_Email',
      'ratings_email', 'commodity-insights_email', 'energy_email', 'sustainable1_email'
    ];
    guideBridge.on('elementValueChanged', function (event, data) {
      var node = data && data.target;
      if (!node || EMAIL_FIELDS.indexOf(node.name) === -1) return;
      var enabled = isBusinessEmail(node.value);
      // Try guideBridge first, fall back to DOM disabled attribute
      var toggled = false;
      ['submit', 'Submit', 'submitButton', 'button_submit'].forEach(function (name) {
        if (toggled) return;
        try {
          var btn = guideBridge.resolveNode(name);
          if (btn) { btn.enabled = enabled; toggled = true; }
        } catch (e) {}
      });
      if (!toggled) {
        var domBtn = document.querySelector('[type="submit"]');
        if (domBtn) domBtn.disabled = !enabled;
      }
    });
  }

  // ── Private: wire validateCheckboxGroup on submit button click ──────────────
  function _wireCheckboxValidation() {
    var CONTAINERS = [
      '.acc-reg-alert-section',
      '.checkbox-group-section',
      '.interest-checkbox-group',
    ];
    var container = null;
    for (var i = 0; i < CONTAINERS.length; i++) {
      if (document.querySelector(CONTAINERS[i])) { container = CONTAINERS[i]; break; }
    }
    if (!container) return;
    var submitBtn = document.querySelector('[type="submit"]');
    if (!submitBtn) return;
    // capture phase so this runs before guideBridge processes the click
    submitBtn.addEventListener('click', function (e) {
      if (!validateCheckboxGroup(container)) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var errEl = document.querySelector('[data-checkbox-error], .checkbox-error-message');
        if (errEl) errEl.style.display = 'block';
      }
    }, true);
  }

  // ── Private: wire checkEmailExists on email field blur ──────────────────────
  function _wireCheckEmailExists() {
    if (!document.querySelector('[data-email-exist-message]')) return;
    guideBridge.on('elementValueChanged', function (event, data) {
      var node = data && data.target;
      if (!node || !/email/i.test(node.name)) return;
      checkEmailExists(null, node.value, '[data-email-exist-message]', '[data-next-button]');
    });
  }

  // ── Private: wire validatePasswordMatch on confirm-password change + submit ────
  function _wirePasswordMatch() {
    var VARIANTS = [
      { pwd: '.match-password-w-cfpassword', confirm: '.match-cfpassword-w-password' },
    ];
    var match = null;
    for (var i = 0; i < VARIANTS.length; i++) {
      if (document.querySelector(VARIANTS[i].pwd) && document.querySelector(VARIANTS[i].confirm)) {
        match = VARIANTS[i]; break;
      }
    }
    if (!match) return;
    // Inline check as user types in confirm-password field
    var cfmInput = document.querySelector(match.confirm + ' input[type="password"]');
    if (cfmInput) {
      cfmInput.addEventListener('input', function () {
        var ok = validatePasswordMatch(match.pwd, match.confirm);
        var errEl = document.querySelector('[data-password-mismatch-error], .password-mismatch-error');
        if (errEl) errEl.style.display = ok ? 'none' : 'block';
      });
    }
    // Block submit when passwords do not match
    var submitBtn = document.querySelector('[type="submit"]');
    if (submitBtn) {
      submitBtn.addEventListener('click', function (e) {
        if (!validatePasswordMatch(match.pwd, match.confirm)) {
          e.stopImmediatePropagation();
          e.preventDefault();
          var errEl = document.querySelector('[data-password-mismatch-error], .password-mismatch-error');
          if (errEl) errEl.style.display = 'block';
        }
      }, true);
    }
  }

  // ── Main entry — called once when guideBridge is ready ──────────────────────
  function _onFormReady() {
    console.log('IIF: form ready, initialising');
    initFormDropdowns();
    initPrepopulation();
    applyRatingsFormStyling();
    applyPreferenceCenterSpacing();
    wireMarketingEmailOptIn();
    wireEmailCompanySync();
    _wireBusinessEmailValidation();
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  if (window.guideBridge) {
    guideBridge.connect(function () { _onFormReady(); });
  }

}());