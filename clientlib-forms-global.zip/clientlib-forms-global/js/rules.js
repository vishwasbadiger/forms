'use strict';
/**
 * SPGlobal AEM Forms — Global Custom Functions
 *
 * Single shared clientlib for all adaptive forms.
 * Authors configure behaviour via Rule Editor → Invoke Function — no per-form JS needed.
 *
 * AEM clientlib category : sp-aem-platform.clientlibs.global.forms.common
 *
 * HOW TO ADD TO A FORM
 *   In AEM Author → Form Properties → Custom Functions → add the category above.
 *   Then configure each rule in the Rule Editor using Invoke Function.
 *
 * FUNCTION INDEX
 * ──────────────────────────────────────────────────────────────────────────────
 *  ★ 17. initFormDropdowns          ONE call — loads ALL dropdowns on any form (use this first)
 *  ──────────────────────────────────────────────────────────────────────────────
 *  01. hideEmptyOption              Hide the empty placeholder row in a dropdown
 *  02. loadDropdown                 Populate any dropdown from a JSON API
 *  03. loadCountryState             Load country list + auto-wire state cascade
 *  04. loadStateOnCountryChange     Populate state dropdown when country changes
 *  05. loadDropdownFromServlet      Load dropdown using a DOM data-attribute URL
 *  06. loadJobFunctionOnCompanyChange  Cascade job-function from company-type
 *  07. loadProductCategoryItems     Cascade product items from a selected category
 *  08. initPrepopulation            Prepopulate form fields from data-user-profile-servlet
 *  09. isBusinessEmail              Returns true if email is NOT a personal domain
 *  10. validateCheckboxGroup        Returns true if at least one checkbox is checked
 *  11. wireEmailCompanySync         Re-sync company name when email field changes
 *  12. applyRatingsFormStyling      Fix HR / toggle-button styling on ratings forms
 *  13. applyPreferenceCenterSpacing Add spacing class on preference-center forms
 *  14. wireMarketingEmailOptIn      Show/hide marketing consent panel on email entry
 *  15. checkEmailExists             Async check if email is already registered
 *  16. validatePasswordMatch        Returns true if password and confirm-password match
 * ──────────────────────────────────────────────────────────────────────────────
 */

// ─── Private helpers ─────────────────────────────────────────────────────────
// (no @name → invisible in Rule Editor, but callable by the public functions)

/**
 * Resolves a dot-notation path inside an object.
 * Auto-parses intermediate JSON strings — handles the AEM Content Fragment Assets API
 * where properties.elements.X.value is a stringified JSON object/array.
 * Example: _getIn(data, 'properties.elements.dropdownListJson.value.sectorExpertise') → [...]
 */
function _getIn(obj, path) {
  if (!path) return obj;
  return path.split('.').reduce(function (o, k) {
    if (o == null) return undefined;
    var val = o[k];
    if (typeof val === 'string') {
      var t = val.trim();
      if (t[0] === '{' || t[0] === '[') {
        try { val = JSON.parse(val); } catch (e) {}
      }
    }
    return val;
  }, obj);
}

/**
 * Populates a <select> element from an items array.
 * Each item may be: { key, value } | { value, label } | plain string.
 * keepPlaceholder=true preserves the first option when its value is '' (the empty option).
 */
function _populateSelect(selectEl, items, keepPlaceholder) {
  if (!selectEl || !Array.isArray(items)) return;
  var placeholder = null;
  if (keepPlaceholder && selectEl.options.length > 0 && selectEl.options[0].value === '') {
    placeholder = selectEl.options[0].cloneNode(true);
  }
  selectEl.innerHTML = '';
  if (placeholder) selectEl.appendChild(placeholder);
  items.forEach(function (item) {
    var opt = document.createElement('option');
    if (typeof item === 'object' && item !== null) {
      opt.value       = item.key   != null ? item.key   : (item.value != null ? item.value : '');
      opt.textContent = item.text  != null ? item.text  :
                        item.value != null ? item.value :
                        item.label != null ? item.label : opt.value;
    } else {
      opt.value = opt.textContent = String(item);
    }
    selectEl.appendChild(opt);
  });
}

/**
 * Fetch JSON from url. Returns a Promise that resolves to the parsed object,
 * or null on HTTP/network error (so callers don't need individual .catch()).
 */
function _fetchJson(url) {
  return fetch(url, { credentials: 'include' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .catch(function () { return null; });
}

// ─── PUBLIC FUNCTIONS ────────────────────────────────────────────────────────


/**
 * @name        hideEmptyOption
 * @description Hides the empty placeholder row (data-empty-option) inside a dropdown wrapper.
 *              Call on the field's Initialize event for every dropdown that shows a blank first option.
 *              Example: hideEmptyOption('.energy_country')
 * @param       {string} wrapperClass  CSS class of the AEM field wrapper, e.g. '.energy_country'
 * @return      {void}
 */
function hideEmptyOption(wrapperClass) {
  var el = document.querySelector(wrapperClass + ' [data-empty-option]');
  if (el) el.classList.add('hidden');
}


/**
 * @name        loadDropdown
 * @description Fetches a JSON API and populates a dropdown with the result.
 *              Use for: country-of-residence lists, job-function lists, industry lists,
 *              company-type initial loads, MOC region lists, and any other single-level dropdown.
 *              Example: loadDropdown('/api/assets/.../job-function-cf.json', '.energy_Job_Function__c', 'JobFunction.option')
 * @param       {string} apiUrl       Full URL of the JSON endpoint (pass as hidden-field value or data-attribute)
 * @param       {string} wrapperClass CSS class of the AEM field wrapper, e.g. '.energy_country'
 * @param       {string} jsonPath     Dot-notation path to the items array inside the JSON response.
 *                                    Leave blank if the root is already an array.
 *                                    Examples: 'countryList', 'JobFunction.option', 'companyTypeList'
 * @return      {void}
 */
function loadDropdown(apiUrl, wrapperClass, jsonPath) {
  if (!apiUrl || !wrapperClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var items = _getIn(data, jsonPath);
    if (!Array.isArray(items)) return;
    var sel = document.querySelector(wrapperClass + ' select');
    if (!sel) return;
    _populateSelect(sel, items, true);
  });
}


/**
 * @name        loadCountryState
 * @description Fetches a country-states JSON, populates the country dropdown, and
 *              automatically wires the state dropdown to cascade when the country changes.
 *              Call on guideRootPanel Initialize (runs once on form load).
 *              The JSON must have structure: { "countryList": [{ "key":"US", "value":"United States", "states":[{"key":"CA","value":"California"}] }] }
 *              Example: loadCountryState(countryStatesUrl.value, '.energy_country', '.energy_state', 'energy_state')
 * @param       {string} apiUrl          URL of the country-states JSON (read from hidden field via guideBridge)
 * @param       {string} countryClass    CSS class of the country dropdown wrapper, e.g. '.energy_country'
 * @param       {string} stateClass      CSS class of the state dropdown wrapper, e.g. '.energy_state'
 * @param       {string} stateFieldName  guideBridge field name for the state field (used to reset value on country change)
 * @return      {void}
 */
function loadCountryState(apiUrl, countryClass, stateClass, stateFieldName) {
  if (!apiUrl || !countryClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;

    var cSel = document.querySelector(countryClass + ' select');
    if (!cSel) return;
    _populateSelect(cSel, countryList, true);

    if (!stateClass) return;

    cSel.addEventListener('change', function () {
      var selected = countryList.find(function (c) {
        var k = c.key != null ? String(c.key) : (c.value != null ? String(c.value) : '');
        return k === cSel.value;
      });
      var states = selected && Array.isArray(selected.states) ? selected.states : [];
      var sSel = document.querySelector(stateClass + ' select');
      if (sSel) _populateSelect(sSel, states, true);
      if (stateFieldName) {
        try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
      }
    });
  });
}


/**
 * @name        loadStateOnCountryChange
 * @description Populates the state dropdown for a given country value.
 *              Call on the country field's Value Commit event.
 *              Arg 1 may be a direct API URL OR a data-attribute name (e.g. 'data-ratings-country-state-cf-servlet').
 *              For AEM Content Fragment CFs, pass the same jsonPath used in the Initialize rule as arg 5
 *              so the function can locate the countryList inside the nested CF response.
 *              Example (Value Commit on ratings_country — CF servlet):
 *                loadStateOnCountryChange('data-ratings-country-state-cf-servlet', ratings_country.value, '.ratings_state', 'ratings_state', 'properties.elements.dropdownListJson.value.countryList')
 *              Example (Value Commit — plain API URL):
 *                loadStateOnCountryChange(countryStatesUrl.value, ratings_country.value, '.ratings_state', 'ratings_state')
 * @param       {string} apiUrlOrAttr        Direct API URL, OR a data-attribute name starting with 'data-'
 * @param       {string} selectedCountryKey  The currently selected country value (pass as fieldName.value in Rule Editor)
 * @param       {string} stateClass          CSS class of the state dropdown wrapper, e.g. '.ratings_state'
 * @param       {string} stateFieldName      guideBridge field name for the state field (to reset on change)
 * @param       {string} countryListJsonPath Optional dot-notation path to the countryList array inside the response.
 *                                           Required when the JSON is a CF response, e.g. 'properties.elements.dropdownListJson.value.countryList'
 * @return      {void}
 */
function loadStateOnCountryChange(apiUrlOrAttr, selectedCountryKey, stateClass, stateFieldName, countryListJsonPath) {
  if (!selectedCountryKey || !stateClass) return;
  var url = apiUrlOrAttr;
  if (apiUrlOrAttr && apiUrlOrAttr.slice(0, 5) === 'data-') {
    var attrEl = document.querySelector('[' + apiUrlOrAttr + ']');
    if (!attrEl) return;
    url = attrEl.getAttribute(apiUrlOrAttr);
  }
  if (!url) return;
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var countryList = countryListJsonPath ? _getIn(data, countryListJsonPath) : null;
    if (!Array.isArray(countryList)) countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;
    var country = countryList.find(function (c) {
      var k = c.key != null ? String(c.key) : (c.value != null ? String(c.value) : '');
      return k === String(selectedCountryKey);
    });
    var states = country && Array.isArray(country.states) ? country.states : [];
    var sSel = document.querySelector(stateClass + ' select');
    if (sSel) _populateSelect(sSel, states, true);
    if (stateFieldName) {
      try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
    }
  });
}


/**
 * @name        loadDropdownFromServlet
 * @description Reads a servlet URL from a DOM data-attribute, fetches JSON, and populates a dropdown.
 *              Used for Ratings and CI/Energy servlet-driven dropdowns where the BE sets the URL
 *              on a container element (e.g. data-ratings-country-state-cf-servlet="...").
 *
 *              AUTO-DETECT: When jsonPath is blank, the function automatically locates the items
 *              array inside the AEM Content Fragment response
 *              (properties.elements.dropdownListJson.value → first array found).
 *              You only need to pass jsonPath if you want a specific key from that object.
 *
 *              STATE CASCADE: Pass stateClass and stateFieldName (args 4 & 5) to automatically
 *              wire the state dropdown — no separate Value Commit rule needed.
 *              The countryList items must have a 'states' array property per country.
 *
 *              Example — simple dropdown, no jsonPath needed:
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise')
 *              Example — country + state cascade in one rule (Initialize only):
 *                loadDropdownFromServlet('data-ratings-country-state-cf-servlet', '.ratings_country', '', '.ratings_state', 'ratings_state')
 *              Example — explicit jsonPath (when auto-detect would pick the wrong key):
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise', 'properties.elements.dropdownListJson.value.sectorExpertise')
 *
 * @param       {string} servletAttrName  The data-attribute name that holds the servlet URL
 * @param       {string} wrapperClass     CSS class of the dropdown wrapper to populate, e.g. '.ratings_country'
 * @param       {string} jsonPath         Optional. Dot-notation path to items. Leave blank for auto-detect.
 * @param       {string} stateClass       Optional. CSS class of the state dropdown to wire, e.g. '.ratings_state'
 * @param       {string} stateFieldName   Optional. guideBridge field name for the state field (to reset on country change)
 * @return      {void}
 */
function loadDropdownFromServlet(servletAttrName, wrapperClass, jsonPath, stateClass, stateFieldName) {
  if (!servletAttrName || !wrapperClass) return;
  var el = document.querySelector('[' + servletAttrName + ']');
  if (!el) return;
  var url = el.getAttribute(servletAttrName);
  if (!url) return;

  if (jsonPath) {
    loadDropdown(url, wrapperClass, jsonPath);
    return;
  }

  // Auto-detect: parse CF response and grab the first array inside dropdownListJson.value
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var inner = _getIn(data, 'properties.elements.dropdownListJson.value');
    var items = null;
    if (inner && typeof inner === 'object' && !Array.isArray(inner)) {
      var keys = Object.keys(inner);
      for (var i = 0; i < keys.length; i++) {
        if (Array.isArray(inner[keys[i]])) { items = inner[keys[i]]; break; }
      }
    }
    if (!items) items = Array.isArray(data) ? data : null;
    if (!Array.isArray(items)) return;

    var cSel = document.querySelector(wrapperClass + ' select');
    if (cSel) _populateSelect(cSel, items, true);

    // Auto-wire state cascade when stateClass provided and items contain a country with states.
    // AEM's custom dropdown widget updates <select>.value via direct property assignment —
    // no native 'change' event fires and guideBridge.on('elementValueChanged') is unreliable
    // across AEM versions. Intercept the value setter on this specific <select> instance
    // instead. Installed AFTER _populateSelect so initial population doesn't trigger it.
    if (stateClass && cSel && items.some(function (c) { return Array.isArray(c.states); })) {
      var handleCountryChange = function (val) {
        if (!val) return;
        var selected = items.find(function (c) {
          var k = c.key != null ? String(c.key) : (c.value != null ? String(c.value) : '');
          return k === String(val);
        });
        var states = selected && Array.isArray(selected.states) ? selected.states : [];
        var sSel = document.querySelector(stateClass + ' select');
        if (sSel) _populateSelect(sSel, states, true);
        if (stateFieldName) {
          try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
        }
      };

      // Capture baseline after _populateSelect so AEM's initial auto-select doesn't fire
      var _lastCountryVal = cSel.value;

      var _onCountryVal = function (v) {
        if (v && v !== _lastCountryVal) {
          _lastCountryVal = v;
          handleCountryChange(v);
        }
      };

      // Path 1: intercept direct .value = x assignments
      try {
        var _selProto = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
        Object.defineProperty(cSel, 'value', {
          configurable: true,
          get: function () { return _selProto.get.call(this); },
          set: function (v) { _selProto.set.call(this, v); _onCountryVal(v); }
        });
      } catch (e) {}

      // Path 2: native DOM change (non-AEM / unit-test contexts)
      cSel.addEventListener('change', function () { _onCountryVal(this.value); });

      // Path 3: poll cSel.value — catches options[x].selected = true and any other
      // internal AEM path that doesn't trigger the setter or a DOM event
      var _poll = setInterval(function () {
        var v = cSel.value;
        if (v && v !== _lastCountryVal) {
          _lastCountryVal = v;
          handleCountryChange(v);
        }
      }, 300);
    }
  });
}


/**
 * @name        loadJobFunctionOnCompanyChange
 * @description Cascades the job-function dropdown when the company-type selection changes.
 *              Fetches the company-type JSON, finds the selected company entry, and populates
 *              the job-function dropdown with that company's jobFunctions array.
 *              Call on the company-type field's Value Commit event.
 *              Example (Value Commit on market-intelligence_Company_Type1__c):
 *                loadJobFunctionOnCompanyChange(companyJobFunctionUrl.value, market-intelligence_Company_Type1__c.value, 'market-intelligence_Job_Function1__c')
 * @param       {string} apiUrl                URL of the company-type/job-function JSON
 * @param       {string} selectedCompanyType   Currently selected company-type value (pass fieldName.value)
 * @param       {string} jobFunctionFieldName  guideBridge field name for the job-function dropdown
 * @return      {void}
 */
function loadJobFunctionOnCompanyChange(apiUrl, selectedCompanyType, jobFunctionFieldName) {
  if (!apiUrl || !selectedCompanyType || !jobFunctionFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var companyList = data.companyTypeList || [];
    var match = companyList.find(function (c) {
      return (c.key != null ? String(c.key) : '') === String(selectedCompanyType);
    });
    var jobs = (match && Array.isArray(match.jobFunctions)) ? match.jobFunctions : [];
    try {
      var node = guideBridge.resolveNode(jobFunctionFieldName);
      if (node) {
        node.enum      = jobs.map(function (j) { return j.key   != null ? j.key   : j.value; });
        node.enumNames = jobs.map(function (j) { return j.value != null ? j.value : j.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @name        loadProductCategoryItems
 * @description Cascades product/service items when a product category is selected.
 *              Fetches the critical-business JSON, finds the matching category, and populates
 *              the product items dropdown.
 *              Call on the product-category field's Value Commit event.
 *              Example: loadProductCategoryItems(criticalBusinessUrl.value, productCategory.value, 'market-intelligence_S_P_Product_Service_Interests__c')
 * @param       {string} apiUrl             URL of the product/critical-business JSON
 * @param       {string} selectedCategory   Currently selected category value (pass fieldName.value)
 * @param       {string} itemsFieldName     guideBridge field name for the product items dropdown
 * @return      {void}
 */
function loadProductCategoryItems(apiUrl, selectedCategory, itemsFieldName) {
  if (!apiUrl || !selectedCategory || !itemsFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var categoryList = data.categoryList || data.productList || data.criticalBusinessList || [];
    var match = categoryList.find(function (c) {
      return (c.key != null ? String(c.key) : '') === String(selectedCategory);
    });
    var items = (match && Array.isArray(match.items)) ? match.items
      : (match && Array.isArray(match.products)) ? match.products : [];
    try {
      var node = guideBridge.resolveNode(itemsFieldName);
      if (node) {
        node.enum      = items.map(function (i) { return i.key   != null ? i.key   : i.value; });
        node.enumNames = items.map(function (i) { return i.value != null ? i.value : i.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @name        initPrepopulation
 * @description Prepopulates form fields from the user-profile API.
 *              Reads the API URL automatically from the data-user-profile-servlet attribute
 *              set by BE on the form container — no URL parameter needed.
 *              If cookieName is provided, the function only runs when that cookie is present
 *              (user is logged in). Pass a blank string to prepopulate for all users.
 *              The API response keys are mapped to AEM field names by prepending fieldPrefix.
 *              Example — ratings (logged-in only):
 *                initPrepopulation('SP_SSO_TOKEN', 'ratings_')
 *              Example — CI (logged-in only):
 *                initPrepopulation('CI-AUTH-JWT', 'commodityinsights_')
 *              Example — Energy (all users):
 *                initPrepopulation('', 'energy_')
 * @param       {string} cookieName   Cookie name to check for login. Pass blank string to skip.
 * @param       {string} fieldPrefix  AEM field name prefix, e.g. 'ratings_', 'energy_', 'commodityinsights_'
 * @return      {void}
 */
function initPrepopulation(cookieName, fieldPrefix) {
  var profileEl = document.querySelector('[data-user-profile-servlet]');
  var apiUrl    = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  if (!apiUrl) return;

  if (cookieName) {
    var cookiePattern = new RegExp('(^|;)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
    if (!cookiePattern.test(document.cookie)) return;
  }

  _fetchJson(apiUrl).then(function (data) {
    if (!data || typeof data !== 'object') return;
    Object.keys(data).forEach(function (apiKey) {
      var val = data[apiKey];
      if (val == null || val === '') return;
      var fieldName = fieldPrefix ? fieldPrefix + apiKey : apiKey;
      try {
        var node = guideBridge.resolveNode(fieldName);
        if (node) node.value = val;
      } catch (e) {}
    });
  });
}


/**
 * @name        checkEmailExists
 * @description Checks whether an email is already registered by calling the user-profile
 *              servlet. If the account exists, shows an error message element and hides
 *              the next/submit button. Used on the email field's Value Commit event in
 *              registration forms to prevent duplicate accounts.
 *              The check is async — the DOM updates after the API responds.
 *              Example: checkEmailExists(userProfileServletUrl.value, ratings_email.value, '[data-email-exist-message]', '[data-next-button]')
 * @param       {string} apiUrl             Profile servlet URL (from hidden field set by BE)
 * @param       {string} emailValue         Current email value (pass fieldName.value in Rule Editor)
 * @param       {string} errorSelector      CSS selector for the error message container to show/hide
 * @param       {string} nextButtonSelector CSS selector for the Next/Submit button to disable when email exists
 * @return      {void}
 */
function checkEmailExists(apiUrl, emailValue, errorSelector, nextButtonSelector) {
  if (!apiUrl) {
    var profileEl = document.querySelector('[data-user-profile-servlet]');
    apiUrl = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  }
  if (!apiUrl || !emailValue || emailValue.indexOf('@') === -1) return;
  var errorEl  = errorSelector      ? document.querySelector(errorSelector)      : null;
  var buttonEl = nextButtonSelector ? document.querySelector(nextButtonSelector) : null;

  fetch(apiUrl, {
    method     : 'POST',
    headers    : { 'Content-Type': 'application/json' },
    credentials: 'include',
    body       : JSON.stringify({ field: 'firstName,email', email: emailValue })
  })
  .then(function (r) { return r.ok ? r.json() : null; })
  .then(function (data) {
    if (!data) return;
    var exists = !!(data.userExists || data.exists || data.accountExists);
    if (errorEl)  errorEl.style.display  = exists ? 'block' : 'none';
    if (buttonEl) buttonEl.disabled      = exists;
  })
  .catch(function () {});
}


/**
 * @name        validatePasswordMatch
 * @description Returns true if the password and confirm-password fields contain the same value.
 *              Use in a Validate rule on both the password field and the confirm-password field.
 *              Example: validatePasswordMatch('.ratings_password', '.confirmPassword')
 * @param       {string} passwordSelector         CSS class of the password field wrapper
 * @param       {string} confirmPasswordSelector  CSS class of the confirm-password field wrapper
 * @return      {boolean}  true = passwords match (valid); false = mismatch (invalid)
 */
function validatePasswordMatch(passwordSelector, confirmPasswordSelector) {
  var pwdInput = document.querySelector(passwordSelector + ' input[type="password"]');
  var cfmInput = document.querySelector(confirmPasswordSelector + ' input[type="password"]');
  if (!pwdInput || !cfmInput) return true;
  return pwdInput.value === cfmInput.value;
}


/**
 * @name        isBusinessEmail
 * @description Returns true if the email address belongs to a business domain
 *              (i.e. is NOT a known personal/consumer email provider).
 *              Use in a field's Enabled or Validate rule on a submit button.
 *              Example (Enabled on Submit): isBusinessEmail(Corporate_email.value)
 * @param       {string} emailValue  The email address to check (pass fieldName.value)
 * @return      {boolean}            true = business email (allow submit); false = personal email (block submit)
 */
function isBusinessEmail(emailValue) {
  if (!emailValue || emailValue.indexOf('@') === -1) return true;
  var domain = emailValue.split('@').pop().toLowerCase();
  var personalDomains = [
    // Global
    'gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.uk', 'yahoo.co.in',
    'yahoo.com.au', 'yahoo.ca', 'yahoo.fr', 'yahoo.de', 'yahoo.es', 'yahoo.it',
    'hotmail.com', 'hotmail.co.uk', 'hotmail.fr', 'hotmail.de', 'hotmail.es', 'hotmail.it',
    'outlook.com', 'outlook.co.uk', 'outlook.fr', 'outlook.de', 'outlook.es',
    'live.com', 'live.co.uk', 'live.fr', 'live.de', 'live.es', 'live.it',
    'msn.com', 'aol.com', 'icloud.com', 'me.com', 'mac.com',
    'protonmail.com', 'protonmail.ch', 'proton.me',
    'zoho.com', 'zohomail.com',
    'inbox.com', 'mail.com', 'email.com', 'usa.com', 'hushmail.com',
    // Russia / Eastern Europe
    'yandex.ru', 'yandex.com', 'yandex.ua', 'yandex.kz', 'yandex.by',
    'mail.ru', 'list.ru', 'bk.ru', 'inbox.ru', 'rambler.ru',
    'ukr.net', 'mail.bg', 'abv.bg',
    // Germany
    'web.de', 'gmx.de', 'gmx.net', 'gmx.com', 'gmx.at', 'gmx.ch',
    'freenet.de', 't-online.de', 'arcor.de',
    // France
    'orange.fr', 'sfr.fr', 'laposte.net', 'free.fr', 'bbox.fr',
    'alice.fr', 'numericable.fr', 'wanadoo.fr', 'neuf.fr',
    // Spain / Italy
    'orange.es', 'terra.es', 'ya.com',
    'libero.it', 'virgilio.it', 'tin.it', 'alice.it', 'tiscali.it', 'fastwebnet.it',
    // Switzerland
    'bluewin.ch', 'sunrise.ch',
    // Brazil
    'bol.com.br', 'uol.com.br', 'globo.com', 'terra.com.br', 'r7.com',
    'ig.com.br', 'oi.com.br', 'pop.com.br', 'zipmail.com.br',
    // China / Asia
    'qq.com', '163.com', '126.com', 'sina.com', 'sina.cn', '139.com',
    'foxmail.com', 'sohu.com', 'aliyun.com', '21cn.com',
    // Korea
    'naver.com', 'daum.net', 'hanmail.net', 'nate.com', 'kakao.com',
    // Japan
    'docomo.ne.jp', 'softbank.ne.jp', 'au.com', 'ezweb.ne.jp',
    // Australia
    'bigpond.com', 'bigpond.net.au', 'optusnet.com.au',
    'internode.on.net', 'tpg.com.au', 'iinet.net.au', 'dodo.com.au',
    // India
    'rediffmail.com', 'sify.com',
    // Other common
    'tutanota.com', 'tutamail.com', 'dispostable.com', 'mailinator.com',
    'guerrillamail.com', 'trashmail.com', 'tempmail.com', 'throwam.com'
  ];
  return personalDomains.indexOf(domain) === -1;
}


/**
 * @name        validateCheckboxGroup
 * @description Returns true if at least one checkbox is checked inside the given container.
 *              Use in a Validate rule on a checkbox group panel.
 *              Example: validateCheckboxGroup('.acc-reg-alert-section')
 * @param       {string} containerSelector  CSS selector for the panel/div wrapping the checkboxes
 * @return      {boolean}                   true = valid (at least one checked); false = invalid
 */
function validateCheckboxGroup(containerSelector) {
  var container = document.querySelector(containerSelector);
  if (!container) return false;
  return container.querySelectorAll('input[type="checkbox"]:checked').length > 0;
}


/**
 * @name        wireEmailCompanySync
 * @description Attaches a focusout listener to the email input so that when the user changes
 *              their email address, the company-name field value is re-synced via guideBridge.
 *              The 2-second delay is required because AEM re-renders the field asynchronously
 *              after the email change event.
 *              Call on guideRootPanel Initialize (once per form load).
 *              Example: wireEmailCompanySync('.market-intelligence_sPGMICustomCompanyName', 'market-intelligence_sPGMICustomCompanyName')
 * @param       {string} companyWrapperClass  CSS class of the company-name field wrapper
 * @param       {string} companyGbFieldName   guideBridge field name for the company-name field
 * @return      {void}
 */
function wireEmailCompanySync(companyWrapperClass, companyGbFieldName) {
  var emailInput = document.querySelector('.guideEmail input[type="email"]');
  if (!emailInput) return;
  emailInput.addEventListener('focusout', function () {
    setTimeout(function () {
      var companyInput = document.querySelector(companyWrapperClass + ' input');
      if (companyInput && companyGbFieldName) {
        try {
          guideBridge.resolveNode(companyGbFieldName).value = companyInput.value;
        } catch (e) {}
      }
    }, 2000);
  });
}


/**
 * @name        applyRatingsFormStyling
 * @description Removes unwanted min-height from HR elements in text draws, cleans up
 *              guideFieldError class on toggle buttons, and adds mb-8 spacing to the
 *              vertical-tab-dropdown. Identical fix required on all ratings forms.
 *              Call on guideRootPanel Initialize.
 * @return      {void}
 */
function applyRatingsFormStyling() {
  document.querySelectorAll('.guideTextDraw hr').forEach(function (hr) {
    hr.style.minHeight = '';
  });
  document.querySelectorAll('.toggleButton.guideFieldError').forEach(function (el) {
    el.classList.remove('guideFieldError');
  });
  var vtd = document.querySelector('.vertical-tab-dropdown');
  if (vtd) vtd.classList.add('mb-8');
}


/**
 * @name        applyPreferenceCenterSpacing
 * @description Walks up from .preference-center-parent to the nearest <form> element
 *              and adds the remove-x-padding class to remove horizontal padding.
 *              Call on guideRootPanel Initialize for preference-center and interest forms.
 * @return      {void}
 */
function applyPreferenceCenterSpacing() {
  var el = document.querySelector('.preference-center-parent');
  if (!el) return;
  var form = el.closest('form');
  if (form) form.classList.add('remove-x-padding');
}


/**
 * @name        wireMarketingEmailOptIn
 * @description Listens for any field value change via guideBridge and shows or hides the
 *              marketingEmailOptIn panel based on whether the email field has a value.
 *              Call on the email field's Initialize event (or guideRootPanel Initialize).
 *              The emailFieldName parameter lets you pass the exact guideBridge field name
 *              for the email field — it differs per division:
 *                ratings / CI / energy → 'email'
 *                corporate forms      → 'Corporate_Email'
 *              Example: wireMarketingEmailOptIn('Corporate_Email')
 *              Example: wireMarketingEmailOptIn('email')
 * @param       {string} emailFieldName  guideBridge field name for the email field (default: 'email')
 * @return      {void}
 */
function wireMarketingEmailOptIn(emailFieldName) {
  var fieldName = emailFieldName || 'email';
  guideBridge.on('elementValueChanged', function () {
    try {
      var emailNode  = guideBridge.resolveNode(fieldName);
      var optInPanel = guideBridge.resolveNode('marketingEmailOptIn');
      if (emailNode && optInPanel) {
        optInPanel.visible = (emailNode.value != null && emailNode.value !== '');
      }
    } catch (e) {}
  });
}


/**
 * @name        initFormDropdowns
 * @description Initialises ALL servlet-driven dropdowns on the current form in ONE call.
 *              Scans the page for every known data-*-servlet attribute, matches it to the
 *              corresponding field wrapper class, fetches the JSON, and populates the dropdown.
 *              Country → State cascades are wired automatically (no separate Value Commit rule).
 *              Company Type → Job Function and Product Category → Product Items cascades
 *              are also wired automatically for MI forms.
 *              Fields that do not exist on the current form are silently skipped.
 *
 *              ── Required BE data-attributes (set on form container) ──────────────────────
 *              Ratings : data-ratings-country-state-cf-servlet
 *                        data-ratings-sector-expertise-cf-servlet
 *                        data-ratings-role-function-cf-servlet
 *                        data-ratings-institution-type-cf-servlet
 *              CI/Energy/Sustainable:
 *                        data-ci-country-states-cf-servlet  (shared across all these BUs)
 *                        data-country-of-residence-servlet
 *                        data-industry-servlet
 *                        data-job-function-servlet
 *              MI      : data-company-type-servlet          (returns { companyTypeList:[...] })
 *                        data-product-category-servlet      (returns { categoryList:[...] })
 *              All BUs : data-user-profile-servlet          (used by initPrepopulation)
 *
 *              ── NOT handled here (call separately) ──────────────────────────────────────
 *              initPrepopulation(cookieName, fieldPrefix) — cookie name and field prefix differ per form
 *              MOC forms (data-countryregionmarket-servlet) — use dynamic class names; call
 *                loadDropdownFromServlet('data-countryregionmarket-servlet', '.yourClass') directly
 *
 *              Example (single rule on guideRootPanel Initialize):
 *                initFormDropdowns()
 *
 * @return      {void}
 */
function initFormDropdowns() {
  var LOAD_MAP = [
    // ── Ratings CF dropdowns ──────────────────────────────────────────────────
    { attr: 'data-ratings-country-state-cf-servlet',
      variants: [
        { field: '.ratings_country', stateField: '.ratings_state', stateGb: 'ratings_state' },
        { field: '.ratings_country', stateField: '.ratings_State', stateGb: 'ratings_State' }
      ]
    },
    { attr: 'data-ratings-sector-expertise-cf-servlet', variants: [
        { field: '.ratings_Customer_Expertise__c' },
        { field: '.ratings_Customer_Expertise'    },
        { field: '.ratings_Sector_Expertise__c'   }
    ]},
    { attr: 'data-ratings-role-function-cf-servlet', variants: [
        { field: '.ratings_Customer_Segment__c' },
        { field: '.ratings_Customer_Segment'    }
    ]},
    { attr: 'data-ratings-institution-type-cf-servlet', variants: [
        { field: '.ratings_Customer_Employer_Type__c' },
        { field: '.ratings_Customer_Employer_Type'    }
    ]},
    // ── CI / Energy / Sustainable shared CF (country + state cascade) ─────────
    { attr: 'data-ci-country-states-cf-servlet',
      variants: [
        { field: '.ci_country',                 stateField: '.ci_state',                 stateGb: 'ci_state'                 },
        { field: '.commodity-insights_country', stateField: '.commodity-insights_state', stateGb: 'commodity-insights_state' },
        { field: '.energy_country',             stateField: '.energy_state',             stateGb: 'energy_state'             },
        { field: '.sustainable1_country',       stateField: '.sustainable1_state',       stateGb: 'sustainable1_state'       },
        { field: '.s1_country',                 stateField: '.s1_state',                 stateGb: 's1_state'                 }
      ]
    },
    // ── Country of residence (no state — single dropdown) ─────────────────────
    { attr: 'data-country-of-residence-servlet', variants: [
        { field: '.ci_country_Of_Residence'                     },
        { field: '.commodity-insights_Country_of_Residence__c'  },
        { field: '.energy_Country_of_Residence__c'              }
    ]},
    // ── Industry ──────────────────────────────────────────────────────────────
    { attr: 'data-industry-servlet', variants: [
        { field: '.ci_industry-dropdown'        },
        { field: '.commodity-insights_industry' },
        { field: '.energy_industry'             }
    ]},
    // ── Job function (initial load) ───────────────────────────────────────────
    { attr: 'data-job-function-servlet', variants: [
        { field: '.ci_job-function-dropdown'           },
        { field: '.commodity-insights_Job_Function__c' },
        { field: '.energy_Job_Function__c'             }
    ]}
  ];

  LOAD_MAP.forEach(function (entry) {
    var attrEl = document.querySelector('[' + entry.attr + ']');
    if (!attrEl) return;
    entry.variants.forEach(function (v) {
      if (!document.querySelector(v.field)) return;
      loadDropdownFromServlet(entry.attr, v.field, '', v.stateField || null, v.stateGb || null);
    });
  });

  // ── MI: company type + job function cascade ───────────────────────────────
  var companyAttrEl = document.querySelector('[data-company-type-servlet]');
  var companyEl     = document.querySelector('.market-intelligence_Company_Type1__c');
  if (companyAttrEl && companyEl) {
    var companyUrl = companyAttrEl.getAttribute('data-company-type-servlet');
    loadDropdown(companyUrl, '.market-intelligence_Company_Type1__c', 'companyTypeList');
    var compSel = companyEl.querySelector('select');
    if (compSel) {
      compSel.addEventListener('change', function () {
        loadJobFunctionOnCompanyChange(companyUrl, compSel.value, 'market-intelligence_Job_Function1__c');
      });
    }
  }

  // ── MI: product category + product items cascade ──────────────────────────
  var productAttrEl = document.querySelector('[data-product-category-servlet]');
  var productCatEl  = document.querySelector('.market-intelligence_sPProductServiceInterestsCategory');
  if (productAttrEl && productCatEl) {
    var productUrl = productAttrEl.getAttribute('data-product-category-servlet');
    loadDropdown(productUrl, '.market-intelligence_sPProductServiceInterestsCategory', 'categoryList');
    var catSel = productCatEl.querySelector('select');
    if (catSel) {
      catSel.addEventListener('change', function () {
        loadProductCategoryItems(productUrl, catSel.value, 'market-intelligence_S_P_Product_Service_Interests__c');
      });
    }
  }
}
