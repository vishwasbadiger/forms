(function () {

  var LOAD_MAP = [
    // Country + state cascade (both casing variants, both state field variants)
    { variants: [
        { field: '.Corporate_Country', stateField: '.Corporate_State',            stateGb: 'Corporate_State'            },
        { field: '.Corporate_Country', stateField: '.Corporate_sPGMICustomState', stateGb: 'Corporate_sPGMICustomState' },
        { field: '.Corporate_country', stateField: '.Corporate_State',            stateGb: 'Corporate_State'            },
        { field: '.Corporate_country', stateField: '.Corporate_sPGMICustomState', stateGb: 'Corporate_sPGMICustomState' }
    ]},
    // Single dropdowns
    { variants: [
        { field: '.Corporate_complianceCountry'          },
        { field: '.Corporate_phoneCode'                  },
        { field: '.Corporate_CountryCode'                },
        { field: '.Corporate_corpCustomPhoneCountryCode' }
    ]},
    { variants: [{ field: '.Corporate_Industry'          }]},
    { variants: [{ field: '.ci_Country_of_Residence__c'  }]}
  ];

  var EMAIL_VARIANTS   = ['Corporate_Email', 'Corporate_email'];
  var EMAIL_FIELDS     = ['Corporate_Email', 'Corporate_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.Corporate_Company_Name',           gbName: 'Corporate_Company_Name'           },
    { wrapper: '.Corporate_Company',                gbName: 'Corporate_Company'                },
    { wrapper: '.Corporate_sPGMICustomCompanyName', gbName: 'Corporate_sPGMICustomCompanyName' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
