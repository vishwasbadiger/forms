(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.energy_country', stateField: '.energy_state', stateGb: 'energy_state' }
    ]},
    { variants: [{ field: '.energy_Country_of_Residence__c' }]},
    { variants: [{ field: '.energy_industry'                 }]},
    { variants: [{ field: '.energy_Job_Function__c'          }]}
  ];

  var EMAIL_VARIANTS   = ['energy_email'];
  var EMAIL_FIELDS     = ['energy_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.energy_company', gbName: 'energy_company' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
