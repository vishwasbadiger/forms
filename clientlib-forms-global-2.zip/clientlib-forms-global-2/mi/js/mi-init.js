(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.market-intelligence_Country', stateField: '.market-intelligence_sPGMICustomState', stateGb: 'market-intelligence_sPGMICustomState' }
    ]}
    // Company Type → Job Function and Product Category → Product Items cascades
    // are wired automatically by initFormDropdowns (common logic, not BU-specific)
  ];

  var EMAIL_VARIANTS   = ['Corporate_email', 'market-intelligence_email'];
  var EMAIL_FIELDS     = ['Corporate_email', 'market-intelligence_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.market-intelligence_sPGMICustomCompanyName', gbName: 'market-intelligence_sPGMICustomCompanyName' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
