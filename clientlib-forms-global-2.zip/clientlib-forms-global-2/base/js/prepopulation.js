function initPrepopulation() {
  var profileEl = document.querySelector('[data-user-profile-servlet]');
  var apiUrl    = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  if (!apiUrl) return;

  // Auto-detect field prefix from the _prepopulate marker class already on the form
  var fieldPrefix = '';
  var markerEl = document.querySelector('[class*="_prepopulate"]');
  if (markerEl) {
    var classes = markerEl.className.split(/\s+/);
    for (var ci = 0; ci < classes.length; ci++) {
      var m = classes[ci].match(/^([a-zA-Z][a-zA-Z0-9-]*)_prepopulate$/);
      if (m) { fieldPrefix = m[1] + '_'; break; }
    }
  }
  if (!fieldPrefix) return;

  // Cookie lookup by marker class prefix — ratings always uses SP_SSO_TOKEN,
  // commodityinsights/energy uses CI-AUTH-JWT (if missing, still run — covers all-users forms)
  var COOKIE_MAP = { ratings: 'SP_SSO_TOKEN', newsletter: 'SP_SSO_TOKEN', commodityinsights: 'CI-AUTH-JWT', energy: 'CI-AUTH-JWT', sustainable1: 'CI-AUTH-JWT' };
  var buPrefix = fieldPrefix.replace(/_$/, '');
  var cookieName = COOKIE_MAP[buPrefix] || '';
  if (cookieName) {
    var cookiePattern = new RegExp('(^|;)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
    if (!cookiePattern.test(document.cookie)) return;
  }

  _fetchJson(apiUrl).then(function (data) {
    if (!data || typeof data !== 'object') return;
    Object.keys(data).forEach(function (apiKey) {
      var val = data[apiKey];
      if (val == null || val === '') return;
      try {
        var node = guideBridge.resolveNode(fieldPrefix + apiKey);
        if (node) node.value = val;
      } catch (e) {}
    });
  });
}


/**
 * @name        checkEmailExists
 * @description Checks whether an email is already registered by calling the user-profile
 *              servlet. If the account exists, shows an error message element and hides
 *              the next/submit button. Used on the email field's Value Commit event in
 *              registration forms to prevent duplicate accounts.
 *              The check is async — the DOM updates after the API responds.
 *              Example: checkEmailExists(userProfileServletUrl.value, ratings_email.value, '[data-email-exist-message]', '[data-next-button]')
 * @param       {string} apiUrl             Profile servlet URL (from hidden field set by BE)
 * @param       {string} emailValue         Current email value (pass fieldName.value in Rule Editor)
 * @param       {string} errorSelector      CSS selector for the error message container to show/hide
 * @param       {string} nextButtonSelector CSS selector for the Next/Submit button to disable when email exists
 * @return      {void}
 */