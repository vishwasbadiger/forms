/**
 * @name        initPrepopulation
 * @description Prepopulates form fields from the user-profile API. Zero parameters.
 *              API URL read from data-user-profile-servlet set by BE on the form container.
 *              Field prefix auto-detected from the _prepopulate marker class on the form
 *              (e.g. .ratings_prepopulate → 'ratings_', .commodityinsights_prepopulate → 'commodityinsights_').
 *              Cookie check is derived automatically from the BU prefix:
 *                ratings / newsletter → SP_SSO_TOKEN
 *                commodityinsights / energy / sustainable1 → CI-AUTH-JWT (runs anyway if missing)
 *              Example: initPrepopulation()
 * @return      {void}
 */
function initPrepopulation() {
  var profileEl = document.querySelector('[data-user-profile-servlet]');
  var apiUrl    = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  if (!apiUrl) return;

  // Auto-detect field prefix from the _prepopulate marker class already on the form
  var fieldPrefix = '';
  var markerEl = document.querySelector('[class*="_prepopulate"]');
  if (markerEl) {
    var classes = markerEl.className.split(/\s+/);
    for (var ci = 0; ci < classes.length; ci++) {
      var m = classes[ci].match(/^([a-zA-Z][a-zA-Z0-9-]*)_prepopulate$/);
      if (m) { fieldPrefix = m[1] + '_'; break; }
    }
  }
  if (!fieldPrefix) return;

  // Cookie lookup by marker class prefix — ratings always uses SP_SSO_TOKEN,
  // commodityinsights/energy uses CI-AUTH-JWT (if missing, still run — covers all-users forms)
  var COOKIE_MAP = { ratings: 'SP_SSO_TOKEN', newsletter: 'SP_SSO_TOKEN', commodityinsights: 'CI-AUTH-JWT', energy: 'CI-AUTH-JWT', sustainable1: 'CI-AUTH-JWT' };
  var buPrefix = fieldPrefix.replace(/_$/, '');
  var cookieName = COOKIE_MAP[buPrefix] || '';
  if (cookieName) {
    var cookiePattern = new RegExp('(^|;)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
    if (!cookiePattern.test(document.cookie)) return;
  }

  _fetchJson(apiUrl).then(function (data) {
    if (!data || typeof data !== 'object') return;
    Object.keys(data).forEach(function (apiKey) {
      var val = data[apiKey];
      if (val == null || val === '') return;
      try {
        var node = guideBridge.resolveNode(fieldPrefix + apiKey);
        if (node) node.value = val;
      } catch (e) {}
    });
  });
}
