/**
 * @name        checkEmailExists
 * @description Checks whether an email is already registered by calling the user-profile
 *              servlet. If the account exists, shows an error message element and hides
 *              the next/submit button. Used on the email field's Value Commit event in
 *              registration forms to prevent duplicate accounts.
 *              The check is async — the DOM updates after the API responds.
 *              Example: checkEmailExists(userProfileServletUrl.value, ratings_email.value, '[data-email-exist-message]', '[data-next-button]')
 * @param       {string} apiUrl             Profile servlet URL (from hidden field set by BE)
 * @param       {string} emailValue         Current email value (pass fieldName.value in Rule Editor)
 * @param       {string} errorSelector      CSS selector for the error message container to show/hide
 * @param       {string} nextButtonSelector CSS selector for the Next/Submit button to disable when email exists
 * @return      {void}
 */
function checkEmailExists(apiUrl, emailValue, errorSelector, nextButtonSelector) {
  if (!apiUrl) {
    var profileEl = document.querySelector('[data-user-profile-servlet]');
    apiUrl = profileEl ? profileEl.getAttribute('data-user-profile-servlet') : null;
  }
  if (!apiUrl || !emailValue || emailValue.indexOf('@') === -1) return;
  var errorEl  = errorSelector      ? document.querySelector(errorSelector)      : null;
  var buttonEl = nextButtonSelector ? document.querySelector(nextButtonSelector) : null;

  fetch(apiUrl, {
    method     : 'POST',
    headers    : { 'Content-Type': 'application/json' },
    credentials: 'include',
    body       : JSON.stringify({ field: 'firstName,email', email: emailValue })
  })
  .then(function (r) { return r.ok ? r.json() : null; })
  .then(function (data) {
    if (!data) return;
    var exists = !!(data.userExists || data.exists || data.accountExists);
    if (errorEl)  errorEl.style.display  = exists ? 'block' : 'none';
    if (buttonEl) buttonEl.disabled      = exists;
  })
  .catch(function () {});
}


/**
 * @name        validatePasswordMatch
 * @description Returns true if the password and confirm-password fields contain the same value.
 *              Use in a Validate rule on both the password field and the confirm-password field.
 *              Example: validatePasswordMatch('.ratings_password', '.confirmPassword')
 * @param       {string} passwordSelector         CSS class of the password field wrapper
 * @param       {string} confirmPasswordSelector  CSS class of the confirm-password field wrapper
 * @return      {boolean}  true = passwords match (valid); false = mismatch (invalid)
 */
function validatePasswordMatch(passwordSelector, confirmPasswordSelector) {
  var pwdInput = document.querySelector(passwordSelector + ' input[type="password"]');
  var cfmInput = document.querySelector(confirmPasswordSelector + ' input[type="password"]');
  if (!pwdInput || !cfmInput) return true;
  return pwdInput.value === cfmInput.value;
}


/**
 * @name        isBusinessEmail
 * @description Returns true if the email address belongs to a business domain
 *              (i.e. is NOT a known personal/consumer email provider).
 *              Use in a field's Enabled or Validate rule on a submit button.
 *              Example (Enabled on Submit): isBusinessEmail(Corporate_email.value)
 * @param       {string} emailValue  The email address to check (pass fieldName.value)
 * @return      {boolean}            true = business email (allow submit); false = personal email (block submit)
 */
function isBusinessEmail(emailValue) {
  if (!emailValue || emailValue.indexOf('@') === -1) return true;
  var domain = emailValue.split('@').pop().toLowerCase();
  var personalDomains = [
    // Global
    'gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.uk', 'yahoo.co.in',
    'yahoo.com.au', 'yahoo.ca', 'yahoo.fr', 'yahoo.de', 'yahoo.es', 'yahoo.it',
    'hotmail.com', 'hotmail.co.uk', 'hotmail.fr', 'hotmail.de', 'hotmail.es', 'hotmail.it',
    'outlook.com', 'outlook.co.uk', 'outlook.fr', 'outlook.de', 'outlook.es',
    'live.com', 'live.co.uk', 'live.fr', 'live.de', 'live.es', 'live.it',
    'msn.com', 'aol.com', 'icloud.com', 'me.com', 'mac.com',
    'protonmail.com', 'protonmail.ch', 'proton.me',
    'zoho.com', 'zohomail.com',
    'inbox.com', 'mail.com', 'email.com', 'usa.com', 'hushmail.com',
    // Russia / Eastern Europe
    'yandex.ru', 'yandex.com', 'yandex.ua', 'yandex.kz', 'yandex.by',
    'mail.ru', 'list.ru', 'bk.ru', 'inbox.ru', 'rambler.ru',
    'ukr.net', 'mail.bg', 'abv.bg',
    // Germany
    'web.de', 'gmx.de', 'gmx.net', 'gmx.com', 'gmx.at', 'gmx.ch',
    'freenet.de', 't-online.de', 'arcor.de',
    // France
    'orange.fr', 'sfr.fr', 'laposte.net', 'free.fr', 'bbox.fr',
    'alice.fr', 'numericable.fr', 'wanadoo.fr', 'neuf.fr',
    // Spain / Italy
    'orange.es', 'terra.es', 'ya.com',
    'libero.it', 'virgilio.it', 'tin.it', 'alice.it', 'tiscali.it', 'fastwebnet.it',
    // Switzerland
    'bluewin.ch', 'sunrise.ch',
    // Brazil
    'bol.com.br', 'uol.com.br', 'globo.com', 'terra.com.br', 'r7.com',
    'ig.com.br', 'oi.com.br', 'pop.com.br', 'zipmail.com.br',
    // China / Asia
    'qq.com', '163.com', '126.com', 'sina.com', 'sina.cn', '139.com',
    'foxmail.com', 'sohu.com', 'aliyun.com', '21cn.com',
    // Korea
    'naver.com', 'daum.net', 'hanmail.net', 'nate.com', 'kakao.com',
    // Japan
    'docomo.ne.jp', 'softbank.ne.jp', 'au.com', 'ezweb.ne.jp',
    // Australia
    'bigpond.com', 'bigpond.net.au', 'optusnet.com.au',
    'internode.on.net', 'tpg.com.au', 'iinet.net.au', 'dodo.com.au',
    // India
    'rediffmail.com', 'sify.com',
    // Other common
    'tutanota.com', 'tutamail.com', 'dispostable.com', 'mailinator.com',
    'guerrillamail.com', 'trashmail.com', 'tempmail.com', 'throwam.com'
  ];
  return personalDomains.indexOf(domain) === -1;
}


/**
 * @name        validateCheckboxGroup
 * @description Returns true if at least one checkbox is checked inside the given container.
 *              Use in a Validate rule on a checkbox group panel.
 *              Example: validateCheckboxGroup('.acc-reg-alert-section')
 * @param       {string} containerSelector  CSS selector for the panel/div wrapping the checkboxes
 * @return      {boolean}                   true = valid (at least one checked); false = invalid
 */
function validateCheckboxGroup(containerSelector) {
  var container = document.querySelector(containerSelector);
  if (!container) return false;
  return container.querySelectorAll('input[type="checkbox"]:checked').length > 0;
}


/**
 * @name        wireEmailCompanySync
 * @description Attaches a focusout listener to the email input so that when the user changes
 *              their email address, the company-name field value is re-synced via guideBridge.
 *              The 2-second delay is required because AEM re-renders the field asynchronously.
 *              Auto-detects the company field across all BUs. No parameters needed.
 *              Call on guideRootPanel Initialize (or let the clientlib IIFE call it).
 * @return      {void}
 */
function wireEmailCompanySync(variants) {
  var emailInput = document.querySelector('.guideEmail input[type="email"]');
  if (!emailInput) return;
  var match = null;
  for (var i = 0; i < variants.length; i++) {
    if (document.querySelector(variants[i].wrapper)) { match = variants[i]; break; }
  }
  if (!match) return;
  emailInput.addEventListener('focusout', function () {
    setTimeout(function () {
      var inp = document.querySelector(match.wrapper + ' input');
      if (inp) {
        try { guideBridge.resolveNode(match.gbName).value = inp.value; } catch (e) {}
      }
    }, 2000);
  });
}


/**
 * @name        applyRatingsFormStyling
 * @description Removes unwanted min-height from HR elements in text draws, cleans up
 *              guideFieldError class on toggle buttons, and adds mb-8 spacing to the
 *              vertical-tab-dropdown. Identical fix required on all ratings forms.
 *              Call on guideRootPanel Initialize.
 * @return      {void}
 */
function applyRatingsFormStyling() {
  document.querySelectorAll('.guideTextDraw hr').forEach(function (hr) {
    hr.style.minHeight = '';
  });
  document.querySelectorAll('.toggleButton.guideFieldError').forEach(function (el) {
    el.classList.remove('guideFieldError');
  });
  var vtd = document.querySelector('.vertical-tab-dropdown');
  if (vtd) vtd.classList.add('mb-8');
}


/**
 * @name        applyPreferenceCenterSpacing
 * @description Walks up from .preference-center-parent to the nearest <form> element
 *              and adds the remove-x-padding class to remove horizontal padding.
 *              Call on guideRootPanel Initialize for preference-center and interest forms.
 * @return      {void}
 */
function applyPreferenceCenterSpacing() {
  var el = document.querySelector('.preference-center-parent');
  if (!el) return;
  var form = el.closest('form');
  if (form) form.classList.add('remove-x-padding');
}


/**
 * @name        wireMarketingEmailOptIn
 * @description Shows or hides the marketingEmailOptIn panel based on whether the email
 *              field has a value. Auto-detects the email field name across all BUs.
 *              Call on guideRootPanel Initialize (or let the clientlib IIFE call it).
 * @return      {void}
 */
function wireMarketingEmailOptIn(emailVariants) {
  var optInPanel = null;
  try { optInPanel = guideBridge.resolveNode('marketingEmailOptIn'); } catch (e) {}
  if (!optInPanel) return;

  // Try each known email field name — first one that resolves wins
  var fieldName = null;
  for (var i = 0; i < emailVariants.length; i++) {
    try { if (guideBridge.resolveNode(emailVariants[i])) { fieldName = emailVariants[i]; break; } } catch (e) {}
  }
  if (!fieldName) return;

  guideBridge.on('elementValueChanged', function () {
    try {
      var emailNode = guideBridge.resolveNode(fieldName);
      var panel     = guideBridge.resolveNode('marketingEmailOptIn');
      if (emailNode && panel) {
        panel.visible = (emailNode.value != null && emailNode.value !== '');
      }
    } catch (e) {}
  });
}
