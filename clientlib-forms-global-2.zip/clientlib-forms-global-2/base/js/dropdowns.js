function hideEmptyOption(wrapperClass) {
  var el = document.querySelector(wrapperClass + ' [data-empty-option]');
  if (el) el.classList.add('hidden');
}


/**
 * @internal    loadDropdown — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Fetches a JSON API and populates a dropdown with the result.
 *              Use for: country-of-residence lists, job-function lists, industry lists,
 *              company-type initial loads, MOC region lists, and any other single-level dropdown.
 *              Example: loadDropdown('/api/assets/.../job-function-cf.json', '.energy_Job_Function__c', 'JobFunction.option')
 * @param       {string} apiUrl       Full URL of the JSON endpoint (pass as hidden-field value or data-attribute)
 * @param       {string} wrapperClass CSS class of the AEM field wrapper, e.g. '.energy_country'
 * @param       {string} jsonPath     Dot-notation path to the items array inside the JSON response.
 *                                    Leave blank if the root is already an array.
 *                                    Examples: 'countryList', 'JobFunction.option', 'companyTypeList'
 * @return      {void}
 */
function loadDropdown(apiUrl, wrapperClass, jsonPath) {
  if (!apiUrl || !wrapperClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var items = _getIn(data, jsonPath);
    if (!Array.isArray(items)) return;
    _setFieldOptions(wrapperClass.replace(/^\./, ''), items);
  });
}


/**
 * @internal    loadCountryState — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Fetches a country-states JSON, populates the country dropdown, and
 *              automatically wires the state dropdown to cascade when the country changes.
 *              Call on guideRootPanel Initialize (runs once on form load).
 *              The JSON must have structure: { "countryList": [{ "key":"US", "value":"United States", "states":[{"key":"CA","value":"California"}] }] }
 *              Example: loadCountryState(countryStatesUrl.value, '.energy_country', '.energy_state', 'energy_state')
 * @param       {string} apiUrl          URL of the country-states JSON (read from hidden field via guideBridge)
 * @param       {string} countryClass    CSS class of the country dropdown wrapper, e.g. '.energy_country'
 * @param       {string} stateClass      CSS class of the state dropdown wrapper, e.g. '.energy_state'
 * @param       {string} stateFieldName  guideBridge field name for the state field (used to reset value on country change)
 * @return      {void}
 */
function loadCountryState(apiUrl, countryClass, stateClass, stateFieldName) {
  if (!apiUrl || !countryClass) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;

    var cSel = document.querySelector(countryClass + ' select');
    if (!cSel) return;
    _populateSelect(cSel, countryList, true);

    if (!stateClass) return;

    cSel.addEventListener('change', function () {
      var selected = countryList.find(function (c) {
        var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
        return k === cSel.value;
      });
      var states = selected && Array.isArray(selected.states) ? selected.states : [];
      var sSel = document.querySelector(stateClass + ' select');
      if (sSel) _populateSelect(sSel, states, true);
      if (stateFieldName) {
        try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
      }
    });
  });
}


/**
 * @internal    loadStateOnCountryChange — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Populates the state dropdown for a given country value.
 *              Call on the country field's Value Commit event.
 *              Arg 1 may be a direct API URL OR a data-attribute name (e.g. 'data-ratings-country-state-cf-servlet').
 *              For AEM Content Fragment CFs, pass the same jsonPath used in the Initialize rule as arg 5
 *              so the function can locate the countryList inside the nested CF response.
 *              Example (Value Commit on ratings_country — CF servlet):
 *                loadStateOnCountryChange('data-ratings-country-state-cf-servlet', ratings_country.value, '.ratings_state', 'ratings_state', 'properties.elements.dropdownListJson.value.countryList')
 *              Example (Value Commit — plain API URL):
 *                loadStateOnCountryChange(countryStatesUrl.value, ratings_country.value, '.ratings_state', 'ratings_state')
 * @param       {string} apiUrlOrAttr        Direct API URL, OR a data-attribute name starting with 'data-'
 * @param       {string} selectedCountryKey  The currently selected country value (pass as fieldName.value in Rule Editor)
 * @param       {string} stateClass          CSS class of the state dropdown wrapper, e.g. '.ratings_state'
 * @param       {string} stateFieldName      guideBridge field name for the state field (to reset on change)
 * @param       {string} countryListJsonPath Optional dot-notation path to the countryList array inside the response.
 *                                           Required when the JSON is a CF response, e.g. 'properties.elements.dropdownListJson.value.countryList'
 * @return      {void}
 */
function loadStateOnCountryChange(apiUrlOrAttr, selectedCountryKey, stateClass, stateFieldName, countryListJsonPath) {
  if (!selectedCountryKey || !stateClass) return;
  var url = apiUrlOrAttr;
  if (apiUrlOrAttr && apiUrlOrAttr.slice(0, 5) === 'data-') {
    var attrEl = document.querySelector('[' + apiUrlOrAttr + ']');
    if (!attrEl) return;
    url = attrEl.getAttribute(apiUrlOrAttr);
  }
  if (!url) return;
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var countryList = countryListJsonPath ? _getIn(data, countryListJsonPath) : null;
    if (!Array.isArray(countryList)) countryList = data.countryList || data;
    if (!Array.isArray(countryList)) return;
    var country = countryList.find(function (c) {
      var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
      return k === String(selectedCountryKey);
    });
    var states = country && Array.isArray(country.states) ? country.states : [];
    var sSel = document.querySelector(stateClass + ' select');
    if (sSel) _populateSelect(sSel, states, true);
    if (stateFieldName) {
      try { guideBridge.resolveNode(stateFieldName).value = ''; } catch (e) {}
    }
  });
}


/**
 * @name        loadDropdownFromServlet
 * @description Reads a servlet URL from a DOM data-attribute, fetches JSON, and populates a dropdown.
 *              Used for Ratings and CI/Energy servlet-driven dropdowns where the BE sets the URL
 *              on a container element (e.g. data-ratings-country-state-cf-servlet="...").
 *
 *              AUTO-DETECT: When jsonPath is blank, the function automatically locates the items
 *              array inside the AEM Content Fragment response
 *              (properties.elements.dropdownListJson.value → first array found).
 *              You only need to pass jsonPath if you want a specific key from that object.
 *
 *              STATE CASCADE: Pass stateClass and stateFieldName (args 4 & 5) to automatically
 *              wire the state dropdown — no separate Value Commit rule needed.
 *              The countryList items must have a 'states' array property per country.
 *
 *              Example — simple dropdown, no jsonPath needed:
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise')
 *              Example — country + state cascade in one rule (Initialize only):
 *                loadDropdownFromServlet('data-ratings-country-state-cf-servlet', '.ratings_country', '', '.ratings_state', 'ratings_state')
 *              Example — explicit jsonPath (when auto-detect would pick the wrong key):
 *                loadDropdownFromServlet('data-ratings-sector-expertise-cf-servlet', '.ratings_Customer_Expertise', 'properties.elements.dropdownListJson.value.sectorExpertise')
 *
 * @param       {string} servletAttrName  The data-attribute name that holds the servlet URL
 * @param       {string} wrapperClass     CSS class of the dropdown wrapper to populate, e.g. '.ratings_country'
 * @param       {string} jsonPath         Optional. Dot-notation path to items. Leave blank for auto-detect.
 * @param       {string} stateClass       Optional. CSS class of the state dropdown to wire, e.g. '.ratings_state'
 * @param       {string} stateFieldName   Optional. guideBridge field name for the state field (to reset on country change)
 * @return      {void}
 */
function loadDropdownFromServlet(servletAttrName, wrapperClass, jsonPath, stateClass, stateFieldName) {
  if (!servletAttrName || !wrapperClass) return;
  var el = document.querySelector('[' + servletAttrName + ']');
  if (!el) return;
  var url = el.getAttribute(servletAttrName);
  if (!url) return;
  _loadDropdownFromUrl(url, wrapperClass, jsonPath, stateClass, stateFieldName);
}

/**
 * @internal  AEM puts data-dropdown-json on the inner .guideFieldWidget div, not the outer wrapper.
 *            Check the element itself first, then fall back to any child that has the attribute.
 */
function loadJobFunctionOnCompanyChange(apiUrl, selectedCompanyType, jobFunctionFieldName) {
  if (!apiUrl || !selectedCompanyType || !jobFunctionFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var companyList = data.companyTypeList || [];
    var match = companyList.find(function (c) {
      return (c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '') === String(selectedCompanyType);
    });
    var jobs = (match && Array.isArray(match.jobFunctions)) ? match.jobFunctions : [];
    try {
      var node = guideBridge.resolveNode(jobFunctionFieldName);
      if (node) {
        node.enum      = jobs.map(function (j) { return j.key   != null ? j.key   : j.value; });
        node.enumNames = jobs.map(function (j) { return j.value != null ? j.value : j.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @internal    loadProductCategoryItems — wrapped by initFormDropdowns(); not needed in Rule Editor
 * @description Cascades product/service items when a product category is selected.
 *              Fetches the critical-business JSON, finds the matching category, and populates
 *              the product items dropdown.
 *              Call on the product-category field's Value Commit event.
 *              Example: loadProductCategoryItems(criticalBusinessUrl.value, productCategory.value, 'market-intelligence_S_P_Product_Service_Interests__c')
 * @param       {string} apiUrl             URL of the product/critical-business JSON
 * @param       {string} selectedCategory   Currently selected category value (pass fieldName.value)
 * @param       {string} itemsFieldName     guideBridge field name for the product items dropdown
 * @return      {void}
 */
function loadProductCategoryItems(apiUrl, selectedCategory, itemsFieldName) {
  if (!apiUrl || !selectedCategory || !itemsFieldName) return;
  _fetchJson(apiUrl).then(function (data) {
    if (!data) return;
    var categoryList = data.categoryList || data.productList || data.criticalBusinessList || [];
    var match = categoryList.find(function (c) {
      return (c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '') === String(selectedCategory);
    });
    var items = (match && Array.isArray(match.items)) ? match.items
      : (match && Array.isArray(match.products)) ? match.products : [];
    try {
      var node = guideBridge.resolveNode(itemsFieldName);
      if (node) {
        node.enum      = items.map(function (i) { return i.key   != null ? i.key   : i.value; });
        node.enumNames = items.map(function (i) { return i.value != null ? i.value : i.key;   });
        node.value = '';
      }
    } catch (e) {}
  });
}


/**
 * @name        initPrepopulation
 * @description Prepopulates form fields from the user-profile API. Zero parameters.
 *              API URL read from data-user-profile-servlet set by BE on the form container.
 *              Field prefix auto-detected from the _prepopulate marker class on the form
 *              (e.g. .ratings_prepopulate → 'ratings_', .commodityinsights_prepopulate → 'commodityinsights_').
 *              Cookie check is derived automatically from the BU prefix:
 *                ratings / newsletter → SP_SSO_TOKEN
 *                commodityinsights / energy / sustainable1 → CI-AUTH-JWT (runs anyway if missing)
 *              Example: initPrepopulation()
 * @return      {void}
 */
function initFormDropdowns(loadMap) {
  var LOAD_MAP = loadMap || [];

  LOAD_MAP.forEach(function (entry) {
    entry.variants.forEach(function (v) {
      var fieldEl = document.querySelector(v.field);
      if (!fieldEl) return;
      var url = _getDropdownJsonUrl(fieldEl);
      if (!url) return;
      _loadDropdownFromUrl(url, v.field, '', v.stateField || null, v.stateGb || null);
    });
  });

  // ── MI: company type + job function cascade ───────────────────────────────
  var companyEl = document.querySelector('.market-intelligence_Company_Type1__c');
  if (companyEl) {
    var companyUrl = _getDropdownJsonUrl(companyEl);
    if (companyUrl) {
      loadDropdown(companyUrl, '.market-intelligence_Company_Type1__c', 'companyTypeList');
      var compSel = companyEl.querySelector('select');
      if (compSel) {
        compSel.addEventListener('change', function () {
          loadJobFunctionOnCompanyChange(companyUrl, compSel.value, 'market-intelligence_Job_Function1__c');
        });
      }
    }
  }

  // ── MI: product category + product items cascade ──────────────────────────
  var productCatEl = document.querySelector('.market-intelligence_sPProductServiceInterestsCategory');
  if (productCatEl) {
    var productUrl = _getDropdownJsonUrl(productCatEl);
    if (productUrl) {
      loadDropdown(productUrl, '.market-intelligence_sPProductServiceInterestsCategory', 'categoryList');
      var catSel = productCatEl.querySelector('select');
      if (catSel) {
        catSel.addEventListener('change', function () {
          loadProductCategoryItems(productUrl, catSel.value, 'market-intelligence_S_P_Product_Service_Interests__c');
        });
      }
    }
  }

}


