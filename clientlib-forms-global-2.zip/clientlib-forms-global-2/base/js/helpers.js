'use strict';
/**
 * SPGlobal AEM Forms — Global Custom Functions
 *
 * Single shared clientlib for all adaptive forms.
 * Authors configure behaviour via Rule Editor → Invoke Function — no per-form JS needed.
 *
 * AEM clientlib category : sp-aem-platform.clientlibs.global.forms.base
 *
 * HOW TO ADD TO A FORM
 *   In AEM Author → Form Properties → Custom Functions → add the category above.
 *   The clientlib self-initialises via an IIFE at the bottom — no Rule Editor rules needed
 *   for standard setup. Rule Editor is only needed for custom per-form logic.
 *
 * FUNCTION INDEX
 * ──────────────────────────────────────────────────────────────────────────────
 *  ★ 17. initFormDropdowns          ONE call — loads ALL dropdowns on any form (use this first)
 *  ──────────────────────────────────────────────────────────────────────────────
 *  01. hideEmptyOption              Hide the empty placeholder row in a dropdown
 *  02. loadDropdown                 Populate any dropdown from a JSON API
 *  03. loadCountryState             Load country list + auto-wire state cascade
 *  04. loadStateOnCountryChange     Populate state dropdown when country changes
 *  05. loadDropdownFromServlet      Load dropdown using a DOM data-attribute URL
 *  06. loadJobFunctionOnCompanyChange  Cascade job-function from company-type
 *  07. loadProductCategoryItems     Cascade product items from a selected category
 *  08. initPrepopulation            Prepopulate form fields from data-user-profile-servlet
 *  09. isBusinessEmail              Returns true if email is NOT a personal domain
 *  10. validateCheckboxGroup        Returns true if at least one checkbox is checked
 *  11. wireEmailCompanySync         Re-sync company name when email field changes
 *  12. applyRatingsFormStyling      Fix HR / toggle-button styling on ratings forms
 *  13. applyPreferenceCenterSpacing Add spacing class on preference-center forms
 *  14. wireMarketingEmailOptIn      Show/hide marketing consent panel on email entry
 *  15. checkEmailExists             Async check if email is already registered
 *  16. validatePasswordMatch        Returns true if password and confirm-password match
 * ──────────────────────────────────────────────────────────────────────────────
 */

// ─── Private helpers ─────────────────────────────────────────────────────────
// (no @name → invisible in Rule Editor, but callable by the public functions)

/**
 * Resolves a dot-notation path inside an object.
 * Auto-parses intermediate JSON strings — handles the AEM Content Fragment Assets API
 * where properties.elements.X.value is a stringified JSON object/array.
 * Example: _getIn(data, 'properties.elements.dropdownListJson.value.sectorExpertise') → [...]
 */
function _getIn(obj, path) {
  if (!path) return obj;
  return path.split('.').reduce(function (o, k) {
    if (o == null) return undefined;
    var val = o[k];
    if (typeof val === 'string') {
      var t = val.trim();
      if (t[0] === '{' || t[0] === '[') {
        try { val = JSON.parse(val); } catch (e) {}
      }
    }
    return val;
  }, obj);
}

/**
 * Populates a <select> element from an items array.
 * Each item may be: { key, value } | { value, label } | plain string.
 * keepPlaceholder=true preserves the first option when its value is '' (the empty option).
 */
function _populateSelect(selectEl, items, keepPlaceholder) {
  if (!selectEl || !Array.isArray(items)) return;
  var placeholder = null;
  if (keepPlaceholder && selectEl.options.length > 0 && selectEl.options[0].value === '') {
    placeholder = selectEl.options[0].cloneNode(true);
  }
  selectEl.innerHTML = '';
  if (placeholder) selectEl.appendChild(placeholder);
  items.forEach(function (item) {
    var opt = document.createElement('option');
    if (typeof item === 'object' && item !== null) {
      opt.value       = item.key   != null ? item.key
                      : item.value != null ? item.value
                      : item.code  != null ? item.code  : '';
      opt.textContent = item.text  != null ? item.text  :
                        item.value != null ? item.value :
                        item.label != null ? item.label : opt.value;
    } else {
      opt.value = opt.textContent = String(item);
    }
    selectEl.appendChild(opt);
  });
}

/**
 * Updates a dropdown field's options via the guideBridge model so AEM's overlay widget
 * re-renders. Falls back to native <select> DOM manipulation for non-AEM contexts.
 * fieldName is the bare field name (no leading dot), e.g. 'ratings_country'.
 */
function _setFieldOptions(fieldName, items) {
  var vals = items.map(function (i) {
    return i.key != null ? String(i.key)
         : i.value != null ? String(i.value)
         : i.code != null ? String(i.code)
         : String(i.text || '');
  });
  var labels = items.map(function (i) { return String(i.text || i.label || ''); });
  try {
    var node = guideBridge.resolveNode(fieldName);
    if (node && node.model) {
      node.model.enumNames = labels;
      node.model.enum = vals;
      // Give AEM time to re-render widget before hiding the empty placeholder
      setTimeout(function () { hideEmptyOption('.' + fieldName); }, 50);
      return;
    }
  } catch (e) {}
  // DOM fallback
  var sel = document.querySelector('.' + fieldName + ' select');
  if (sel) {
    _populateSelect(sel, items, true);
    hideEmptyOption('.' + fieldName);
  }
}

/**
 * Fetch JSON from url. Returns a Promise that resolves to the parsed object,
 * or null on HTTP/network error (so callers don't need individual .catch()).
 */
function _fetchJson(url) {
  return fetch(url, { credentials: 'include' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .catch(function () { return null; });
}

// ─── PUBLIC FUNCTIONS ────────────────────────────────────────────────────────


/**
 * @internal  Reads the data-dropdown-json attribute from a field element.
 *            AEM puts data-dropdown-json on the inner .guideFieldWidget div, not the outer wrapper.
 *            Check the element itself first, then fall back to any child that has the attribute.
 */
function _getDropdownJsonUrl(el) {
  var url = el.getAttribute('data-dropdown-json');
  if (url) return url;
  var inner = el.querySelector('[data-dropdown-json]');
  return inner ? inner.getAttribute('data-dropdown-json') : null;
}

/**
 * @internal  Shared fetch+populate logic used by loadDropdownFromServlet and initFormDropdowns.
 *            Not intended for direct use in Rule Editor.
 */
function _loadDropdownFromUrl(url, wrapperClass, jsonPath, stateClass, stateFieldName) {
  if (!url || !wrapperClass) return;

  if (jsonPath) {
    loadDropdown(url, wrapperClass, jsonPath);
    return;
  }

  // Auto-detect: parse CF response and grab the first array inside dropdownListJson.value
  _fetchJson(url).then(function (data) {
    if (!data) return;
    var inner = _getIn(data, 'properties.elements.dropdownListJson.value')
             || _getIn(data, 'elements.dropdownListJson.value');
    // CF stores the dropdown list as a JSON string inside the value field — parse it first
    if (typeof inner === 'string') {
      try { inner = JSON.parse(inner); } catch (e) { inner = null; }
    }
    var items = null;
    if (inner && typeof inner === 'object' && !Array.isArray(inner)) {
      var keys = Object.keys(inner);
      for (var i = 0; i < keys.length; i++) {
        if (Array.isArray(inner[keys[i]])) { items = inner[keys[i]]; break; }
      }
    }
    if (!items) items = Array.isArray(data) ? data : null;
    if (!Array.isArray(items)) return;

    var countryFieldName = wrapperClass.replace(/^\./, '');
    _setFieldOptions(countryFieldName, items);

    if (stateClass && items.some(function (c) { return Array.isArray(c.states); })) {
      var stFN = stateClass.replace(/^\./, '');

      var handleCountryChange = function (val) {
        if (!val) return;
        var selected = items.find(function (c) {
          var k = c.key != null ? String(c.key) : c.value != null ? String(c.value) : c.code != null ? String(c.code) : '';
          return k === String(val);
        });
        var states = selected && Array.isArray(selected.states) ? selected.states : [];

        // Show/hide + mandatory mirrors what the old 6.5 code did via guideBridge
        try {
          var stateNode = guideBridge.resolveNode(stFN);
          if (stateNode) {
            stateNode.value     = '';
            stateNode.visible   = states.length > 0;
            stateNode.mandatory = states.length > 0;
          }
        } catch (e) {}

        // Populate options via native DOM — same approach as original 6.5 code
        var sSel = document.querySelector(stateClass + ' select');
        if (sSel) {
          sSel.innerHTML = '';

          var emptyOpt = document.createElement('option');
          emptyOpt.value = '';
          emptyOpt.textContent = 'State';
          sSel.appendChild(emptyOpt);

          states.forEach(function (s) {
            var opt = document.createElement('option');
            opt.value       = s.text || s.code || s.value || '';
            opt.textContent = s.text || '';
            sSel.appendChild(opt);
          });

          sSel.value = '';
        }
      };

      var _lastCV = '';
      // Primary: guideBridge elementValueChanged — old 6.5 code used data.target (not data.resolvedNode)
      try {
        guideBridge.on('elementValueChanged', function (event, data) {
          var node = data && data.target;
          if (!node || node.name !== countryFieldName) return;
          var v = node.value;
          if (v && v !== _lastCV) { _lastCV = v; handleCountryChange(v); }
        });
      } catch (e) {}

      // Fallback: poll guideBridge model — fires on prepopulation and any path guideBridge misses
      setInterval(function () {
        try {
          var v = guideBridge.resolveNode(countryFieldName).value;
          if (v && v !== _lastCV) { _lastCV = v; handleCountryChange(v); }
        } catch (e) {}
      }, 300);
    }
  });
}