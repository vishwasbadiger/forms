// ─── Wiring helpers (called from BU init IIFEs) ─────────────────────────────
function _wireBusinessEmailValidation(emailFields) {
  guideBridge.on('elementValueChanged', function (event, data) {
    var node = data && data.target;
    if (!node || emailFields.indexOf(node.name) === -1) return;
    var enabled = isBusinessEmail(node.value);
    // Try guideBridge first, fall back to DOM disabled attribute
    var toggled = false;
    ['submit', 'Submit', 'submitButton', 'button_submit'].forEach(function (name) {
      if (toggled) return;
      try {
        var btn = guideBridge.resolveNode(name);
        if (btn) { btn.enabled = enabled; toggled = true; }
      } catch (e) {}
    });
    if (!toggled) {
      var domBtn = document.querySelector('[type="submit"]');
      if (domBtn) domBtn.disabled = !enabled;
    }
  });
}

function _wireCheckboxValidation() {
  var CONTAINERS = [
    '.acc-reg-alert-section',
    '.checkbox-group-section',
    '.interest-checkbox-group',
  ];
  var container = null;
  for (var i = 0; i < CONTAINERS.length; i++) {
    if (document.querySelector(CONTAINERS[i])) { container = CONTAINERS[i]; break; }
  }
  if (!container) return;
  var submitBtn = document.querySelector('[type="submit"]');
  if (!submitBtn) return;
  // capture phase so this runs before guideBridge processes the click
  submitBtn.addEventListener('click', function (e) {
    if (!validateCheckboxGroup(container)) {
      e.stopImmediatePropagation();
      e.preventDefault();
      var errEl = document.querySelector('[data-checkbox-error], .checkbox-error-message');
      if (errEl) errEl.style.display = 'block';
    }
  }, true);
}

function _wireCheckEmailExists() {
  if (!document.querySelector('[data-email-exist-message]')) return;
  guideBridge.on('elementValueChanged', function (event, data) {
    var node = data && data.target;
    if (!node || !/email/i.test(node.name)) return;
    checkEmailExists(null, node.value, '[data-email-exist-message]', '[data-next-button]');
  });
}

function _wirePasswordMatch() {
  var VARIANTS = [
    { pwd: '.match-password-w-cfpassword', confirm: '.match-cfpassword-w-password' },
  ];
  var match = null;
  for (var i = 0; i < VARIANTS.length; i++) {
    if (document.querySelector(VARIANTS[i].pwd) && document.querySelector(VARIANTS[i].confirm)) {
      match = VARIANTS[i]; break;
    }
  }
  if (!match) return;
  // Inline check as user types in confirm-password field
  var cfmInput = document.querySelector(match.confirm + ' input[type="password"]');
  if (cfmInput) {
    cfmInput.addEventListener('input', function () {
      var ok = validatePasswordMatch(match.pwd, match.confirm);
      var errEl = document.querySelector('[data-password-mismatch-error], .password-mismatch-error');
      if (errEl) errEl.style.display = ok ? 'none' : 'block';
    });
  }
  // Block submit when passwords do not match
  var submitBtn = document.querySelector('[type="submit"]');
  if (submitBtn) {
    submitBtn.addEventListener('click', function (e) {
      if (!validatePasswordMatch(match.pwd, match.confirm)) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var errEl = document.querySelector('[data-password-mismatch-error], .password-mismatch-error');
        if (errEl) errEl.style.display = 'block';
      }
    }, true);
  }
}