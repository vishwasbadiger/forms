(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.ci_country',                 stateField: '.ci_state',                 stateGb: 'ci_state'                 },
        { field: '.commodity-insights_country', stateField: '.commodity-insights_state', stateGb: 'commodity-insights_state' }
    ]},
    { variants: [
        { field: '.ci_country_Of_Residence'                    },
        { field: '.commodity-insights_Country_of_Residence__c' }
    ]},
    { variants: [
        { field: '.ci_industry-dropdown'        },
        { field: '.commodity-insights_industry' }
    ]},
    { variants: [
        { field: '.ci_job-function-dropdown'           },
        { field: '.commodity-insights_Job_Function__c' }
    ]}
  ];

  var EMAIL_VARIANTS   = ['commodity-insights_email'];
  var EMAIL_FIELDS     = ['commodity-insights_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.commodity-insights_company', gbName: 'commodity-insights_company' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
