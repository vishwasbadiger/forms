(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.ratings_country', stateField: '.ratings_state', stateGb: 'ratings_state' },
        { field: '.ratings_country', stateField: '.ratings_State', stateGb: 'ratings_State' }
    ]},
    { variants: [
        { field: '.ratings_Customer_Expertise__c' },
        { field: '.ratings_Customer_Expertise'    },
        { field: '.ratings_Sector_Expertise__c'   }
    ]},
    { variants: [
        { field: '.ratings_Customer_Segment__c' },
        { field: '.ratings_Customer_Segment'    }
    ]},
    { variants: [
        { field: '.ratings_Customer_Employer_Type__c' },
        { field: '.ratings_Customer_Employer_Type'    }
    ]}
  ];

  var EMAIL_VARIANTS   = ['ratings_email'];
  var EMAIL_FIELDS     = ['ratings_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.ratings_Company_Name', gbName: 'ratings_Company_Name' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    applyRatingsFormStyling();
    applyPreferenceCenterSpacing();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
