(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.automotive-insights_Country'                                                                                               },
        { field: '.market-intelligence_Country', stateField: '.market-intelligence_sPGMICustomState', stateGb: 'market-intelligence_sPGMICustomState' }
    ]},
    { variants: [
        { field: '.automotive-insights_Industry' },
        { field: '.market-intelligence_Industry' }
    ]}
  ];

  var EMAIL_VARIANTS   = ['Corporate_email', 'automotive-insights_Email'];
  var EMAIL_FIELDS     = ['Corporate_email', 'automotive-insights_Email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.market-intelligence_sPGMICustomCompanyName', gbName: 'market-intelligence_sPGMICustomCompanyName' },
    { wrapper: '.automotive-insights_Company',                gbName: 'automotive-insights_Company'                }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
