(function () {

  var LOAD_MAP = [
    { variants: [
        { field: '.sustainable1_country', stateField: '.sustainable1_state', stateGb: 'sustainable1_state' },
        { field: '.s1_country',           stateField: '.s1_state',           stateGb: 's1_state'           }
    ]}
  ];

  var EMAIL_VARIANTS   = ['sustainable1_email'];
  var EMAIL_FIELDS     = ['sustainable1_email'];
  var COMPANY_VARIANTS = [
    { wrapper: '.sustainable1_company', gbName: 'sustainable1_company' }
  ];

  function _onFormReady() {
    initFormDropdowns(LOAD_MAP);
    initPrepopulation();
    wireEmailCompanySync(COMPANY_VARIANTS);
    wireMarketingEmailOptIn(EMAIL_VARIANTS);
    _wireBusinessEmailValidation(EMAIL_FIELDS);
    _wireCheckboxValidation();
    _wireCheckEmailExists();
    _wirePasswordMatch();
  }

  var _called = false;
  function _once() { if (_called) return; _called = true; _onFormReady(); }
  if (window.guideBridge && typeof guideBridge.connect === 'function') guideBridge.connect(_once);
  if (document.readyState === 'complete') setTimeout(_once, 200);
  else window.addEventListener('load', function () { setTimeout(_once, 200); });

}());
